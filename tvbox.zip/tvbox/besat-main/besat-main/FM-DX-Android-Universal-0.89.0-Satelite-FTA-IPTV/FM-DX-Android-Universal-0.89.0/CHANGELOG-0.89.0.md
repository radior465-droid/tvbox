# FM-DX Android Universal 0.89.0

## Satélite e canais FTA
- Mantém o cadastro local de transponders DVB-S/S2 na tela Internet Radio & TV.
- Adiciona cadastro local de canais FTA de TV e rádio.
- Permite registrar satélite, parâmetros do transponder, Service ID, URL pública opcional e situação de acesso.
- Inclui pesquisa e exclusão de canais cadastrados.
- O status FTA é explicitamente informado pelo usuário; a interface não declara um canal como aberto sem confirmação.
- Atualiza a versão Android para 0.89.0 (versionCode 64).

## Limitações técnicas
- Não foi adicionado driver nem sintonia RF DVB-S/S2.
- A recepção física exige receptor compatível e integração específica de hardware.
- A lista de canais e os transponders são armazenados localmente no navegador da interface.
