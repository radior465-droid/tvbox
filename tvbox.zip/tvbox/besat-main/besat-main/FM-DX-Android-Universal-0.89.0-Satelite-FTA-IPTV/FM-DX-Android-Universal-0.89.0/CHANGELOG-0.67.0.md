# FM-DX Android Universal 0.67.0 — Serviço nativo de áudio em segundo plano

## Novidades
- Serviço Android nativo em primeiro plano (`mediaPlayback`) para reproduzir uma URL direta de áudio HTTP/HTTPS fora do WebView.
- Notificação persistente com ações de pausar, retomar e parar.
- Tela própria no aplicativo para informar o nome da estação e a URL direta do fluxo.
- Validação conservadora de URL: somente HTTP/HTTPS, host obrigatório, sem credenciais embutidas e limite de 4096 caracteres.
- Permissões e declaração do serviço atualizadas para Android moderno.
- Testes unitários para validação de URLs.

## Limitações importantes
- Este serviço reproduz áudio por `android.media.MediaPlayer`; compatibilidade de codecs, formatos de playlist e protocolos varia conforme a versão do Android e o servidor. Use preferencialmente uma URL direta de áudio compatível.
- HLS/DASH, vídeo/TV, DRM, autenticação proprietária e controle da reprodução que acontece dentro do WebView não são prometidos por este serviço.
- O serviço em primeiro plano melhora a continuidade ao sair da tela, mas o Android, fabricantes, economia de bateria, permissões e políticas do sistema ainda podem interromper a reprodução.
- A permissão de notificações pode ser solicitada/gerenciada pelo Android; se estiver bloqueada, a visibilidade da notificação pode ser limitada.
- Não foi possível validar em aparelhos físicos nem compilar APK neste ambiente. O código-fonte e os testes foram verificados; a compilação final deve ocorrer no GitHub Actions/Android SDK.
