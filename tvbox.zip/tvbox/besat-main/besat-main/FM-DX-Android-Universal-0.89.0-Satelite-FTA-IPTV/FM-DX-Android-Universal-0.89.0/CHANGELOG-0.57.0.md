# FM-DX Android Universal 0.57.0 — HTTPS Playlist Scanner

## Novidades
- Parser M3U/M3U8 com metadados `EXTINF`: `tvg-name`, `tvg-id`, `tvg-logo`, `group-title` e duração.
- Resolução de links relativos usando a URL-base da playlist.
- Classificação heurística de rádio/TV e identificação inicial de formatos por extensão e Content-Type.
- Nova API autenticada `POST /api/internet-media/scan-playlist`.
- Varredura limitada a 100 entradas, quatro consultas simultâneas, leitura limitada e timeout por destino.
- Status pontual: ativo, indisponível, requer autorização, redirecionamento, tempo esgotado ou não confirmado.
- Favoritos persistidos no `localStorage` do navegador, com filtro de favoritos.
- Ação para analisar/reproduzir individualmente cada entrada.

## Segurança e limitações
- Somente URLs HTTP/HTTPS fornecidas explicitamente pelo administrador.
- Endereços locais/privados continuam bloqueados; redirecionamentos não são seguidos.
- A varredura não contorna autenticação, DRM, CORS, paywall ou bloqueios de operadora.
- A classificação é heurística; nomes/grupos podem estar ausentes ou incorretos na playlist.
- "Ativo" significa apenas que a consulta pontual retornou HTTP 2xx; não garante reprodução contínua.
- Favoritos ficam no armazenamento local do navegador e não são sincronizados entre dispositivos.

## Testes
- Testes unitários de parsing, resolução de URLs, metadados e classificação adicionados.
- Testes de rede real exigem playlists públicas autorizadas e ambiente com conectividade.
