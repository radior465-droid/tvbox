# FM-DX Android Universal 0.54.0 — Internet Radio & TV Discovery

## Novidades
- Primeiro módulo de análise de streams de Internet fornecidos explicitamente pelo administrador.
- Identificação inicial de MP3, AAC, OGG, Opus, HLS, MPEG-DASH, MPEG-TS e tipos genéricos de áudio/vídeo.
- Leitura limitada de playlists M3U/M3U8 e resolução de entradas relativas.
- Endpoint `POST /api/internet-media/inspect` com autenticação de administrador.
- Limite de leitura de 256 KiB, timeout de 8 segundos e sem seguir redirecionamentos automaticamente.
- Bloqueio de URLs que resolvam para endereços locais/privados, reduzindo risco de SSRF.
- Testes automatizados para classificação, playlists e endereços privados.

## Limitações conhecidas
- Esta versão analisa somente URLs informadas pelo usuário; não captura tráfego de outros aplicativos.
- HTTPS protege o conteúdo em trânsito. Não há interceptação TLS, quebra de DRM, paywall ou restrições de operadora.
- Não inclui ainda interface visual nem reprodução de streams; o endpoint é a base para a próxima etapa.
- Não é um aplicativo Android nativo: o ZIP de origem continua sendo o projeto FM-DX Webserver em Node.js.
