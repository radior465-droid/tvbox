# FM-DX Android Universal 0.84.0 — Scanner SDR remoto por URL

- Adiciona o módulo **Scanner SDR Universal por URL** à tela Internet Radio & TV.
- Analisa uma URL HTTP/HTTPS pública informada pelo usuário e reconhece indicadores de KiwiSDR, OpenWebRX, WebSDR e SpyServer/SDR#.
- Tenta extrair faixas de frequência somente quando a interface as anuncia explicitamente em texto/metadados reconhecíveis.
- Exibe status HTTP, disponibilidade, plataforma identificada e link para abrir a interface remota.
- A consulta é limitada em tamanho e tempo, exige autenticação administrativa e não segue redirecionamentos.
- Não faz varredura global da Internet, não enumera redes/hosts, não sintoniza frequências por si só e não garante que a interface permita ouvir no navegador.
- As faixas LW/MW/SW/HF/VHF/UHF só podem ser apresentadas quando o servidor SDR fornecer essa informação; a URL isolada não revela necessariamente o hardware nem toda a faixa sintonizável.

## Verificação
- `node --check` em `server/internet_media.js` e `server/endpoints.js`.
- `npm test`: testes do projeto executados com sucesso.
