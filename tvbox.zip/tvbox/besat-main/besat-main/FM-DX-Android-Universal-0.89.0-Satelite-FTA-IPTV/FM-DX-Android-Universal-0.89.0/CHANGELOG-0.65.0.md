# FM-DX Android Universal 0.65.0 — Reprodução Móvel Avançada

- Controle de volume de 0 a 100%, aplicado ao áudio e vídeo da central.
- Temporizador local para parar a reprodução após 15, 30, 45, 60, 90 ou 120 minutos.
- Modo contínuo persistente: avança pela fila; quando a fila termina, repete o canal atual após o evento `ended`.
- Ajustes responsivos para telas estreitas e controles maiores para toque.
- Temporizador funciona enquanto a página permanece ativa; navegadores podem suspender temporizadores em segundo plano.

Não contorna autenticação, CORS, DRM ou restrições das fontes.
