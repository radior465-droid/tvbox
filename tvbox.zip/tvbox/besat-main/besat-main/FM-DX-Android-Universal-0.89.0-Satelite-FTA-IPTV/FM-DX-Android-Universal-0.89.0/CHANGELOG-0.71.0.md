# 0.71.0 — Diagnóstico e permissão para TV USB

- Inventário USB detalhado: VID/PID e classe, subclasse e protocolo de cada interface.
- Solicitação de permissão USB pelo diálogo oficial do Android, por dispositivo conectado.
- Atualização do diagnóstico após a resposta de permissão.
- Heurística de identificação continua conservadora: classe de vídeo/proprietária é indício, não prova de tuner.
- Documentadas as etapas ainda necessárias para recepção: driver/protocolo do chipset, demodulador, padrão regional e decodificação.
- Não implementa sintonia RF, captura de transporte nem suporte universal a dongles; isso depende do hardware e de drivers específicos.
