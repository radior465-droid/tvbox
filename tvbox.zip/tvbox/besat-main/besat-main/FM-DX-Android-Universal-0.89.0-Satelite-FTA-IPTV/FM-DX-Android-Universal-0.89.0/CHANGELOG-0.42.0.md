# FM-DX Android Universal 0.42.0 — Universal Connectivity Engine

## Novidades
- Novo painel de diagnóstico de conectividade integrado à tela inicial.
- Inventário somente de leitura para rede ativa, Wi-Fi, rede móvel, Bluetooth, USB/OTG, Ethernet e NFC.
- Identificação do transporte atualmente ativo e indicação de acesso à internet validado pelo Android.
- Contagem e identificação USB por IDs de fabricante/produto, sem presumir compatibilidade de receptor.
- Permissão `ACCESS_NETWORK_STATE` adicionada; nenhuma permissão de localização ou ativação automática de rádio é solicitada.

## Limites e privacidade
- O módulo não liga/desliga Wi-Fi, Bluetooth ou rede móvel e não altera configurações do aparelho.
- A presença de Bluetooth/NFC/USB não significa que exista acessório pareado ou driver compatível.
- A descoberta entre celulares, ponte de áudio/RDS e protocolos de SDR são etapas futuras; esta versão prepara o diagnóstico, não implementa transmissão de áudio.
- Não coleta SSID, endereço IP, localização, identificadores do aparelho ou envia dados para servidores.

## Validação
- Verificação estrutural dos arquivos Kotlin, Manifest e configuração Gradle.
- Compilação Android e testes em aparelhos reais ainda precisam ser executados com JDK 17, Android SDK e Gradle.
