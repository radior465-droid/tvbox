# FM-DX Android Universal 0.63.0 — Central de Reprodução Universal

## Novidades
- Central unificada de reprodução de rádio e TV na interface Internet Media.
- Reprodução direta de canais selecionados na biblioteca, com suporte condicional a HTML5, HLS.js e DASH.js.
- Fila local de até 100 canais, com ações para tocar e remover itens.
- Histórico local dos últimos 30 canais reproduzidos, com reprodução novamente.
- Retomada do último canal selecionado, salva no navegador.
- Controles de reproduzir/pausar e parar.
- Estado da fila, histórico e último canal armazenados em localStorage, sem armazenar credenciais.

## Segurança e limitações
- Aceita somente URLs HTTP/HTTPS sem usuário/senha.
- Não contorna DRM, autenticação, CORS, paywall ou bloqueios do servidor.
- A compatibilidade depende do navegador, codec, origem e servidor de transmissão.
- Fila, histórico e retomada são locais ao navegador e não sincronizam entre aparelhos.
- Reprodução em segundo plano/tela bloqueada não é garantida.

## Verificação
- Sintaxe JavaScript da interface verificada com Node.js.
- Suíte automatizada do servidor executada com `npm test`.
- Integridade do arquivo ZIP verificada com `unzip -t`.
- Não foi compilado APK nem realizado teste em hardware físico.
