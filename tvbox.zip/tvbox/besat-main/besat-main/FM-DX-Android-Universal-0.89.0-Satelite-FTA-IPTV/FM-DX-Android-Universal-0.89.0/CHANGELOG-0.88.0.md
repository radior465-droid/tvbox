# FM-DX Universal 0.88.0 — Pesquisa ampliada de servidores SDR públicos

- Acrescenta seis atalhos de pesquisa para localizar receptores públicos KiwiSDR, OpenWebRX, WebSDR, Web-888, SDR com VHF/UHF e SDR de HF/ondas curtas.
- A interface apresenta os atalhos junto ao catálogo de diretórios SDR e abre as pesquisas em nova aba.
- O catálogo passa para a versão 3.
- As pesquisas são executadas pelo mecanismo de busca externo. O aplicativo não faz rastreamento indiscriminado da internet nem confirma automaticamente que os servidores encontrados estejam ativos.
- A inspeção de um servidor continua sendo feita individualmente por URL, respeitando as proteções existentes contra destinos locais/privados.
