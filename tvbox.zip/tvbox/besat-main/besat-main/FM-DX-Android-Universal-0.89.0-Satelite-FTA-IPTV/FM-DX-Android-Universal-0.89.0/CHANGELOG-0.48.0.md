# FM-DX Android Universal 0.48.0

## Espectro virtual animado e testes
- Gráfico Canvas para exibir o espectro FFT com grade, escala em dBFS e eixo de frequência normalizado.
- Atualização periódica opcional a cada 700 ms com novas amostras I/Q sintéticas.
- Controles para gerar um quadro, iniciar e parar a animação.
- A animação é interrompida ao sair do laboratório ou encerrar a Activity.
- Testes unitários JUnit para reprodutibilidade do gerador, saída FFT, validação de tamanho e coerência das frequências.

## Limites
O gráfico apresenta exclusivamente dados sintéticos do VirtualRfLab. Não representa varredura do ambiente, intensidade recebida, estações reais nem ocupação de banda. Captura real exige hardware, driver e integração validados.

## Validação
O ZIP foi verificado estruturalmente. Os testes JUnit foram adicionados, mas precisam ser executados com Gradle/Android Studio; não foi realizada compilação Android completa neste ambiente.
