package br.com.fmdx.android.tv

import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.hardware.usb.UsbManager
import android.os.Build

/** Inventário USB e solicitação explícita de permissão; não inicia sintonia/captura RF. */
class UsbTvReceiverDiscovery(private val context: Context) {
    private val usb = context.getSystemService(Context.USB_SERVICE) as UsbManager
    private val permissionAction = context.packageName + ".USB_TV_PERMISSION"

    fun scan(): List<TvUsbEvidence> = usb.deviceList.values.map { device ->
        val interfaces = (0 until device.interfaceCount).map { index ->
            val item = device.getInterface(index)
            TvUsbInterfaceEvidence(index, item.interfaceClass, item.interfaceSubclass, item.interfaceProtocol)
        }
        val (likely, notes) = TvCompatibility.classify(interfaces.map { it.interfaceClass })
        TvUsbEvidence(
            deviceName = device.deviceName,
            vendorId = device.vendorId,
            productId = device.productId,
            interfaceCount = device.interfaceCount,
            hasPermission = usb.hasPermission(device),
            likelyTuner = likely,
            notes = notes,
            interfaces = interfaces
        )
    }

    /** Exibe o diálogo oficial do Android. O callback informa somente a concessão de acesso USB. */
    fun requestPermission(deviceName: String, onResult: (Boolean) -> Unit): Boolean {
        val device = usb.deviceList[deviceName] ?: return false
        if (usb.hasPermission(device)) { onResult(true); return true }
        val requestCode = (device.vendorId * 31 + device.productId) and 0x7fffffff
        val intent = Intent(permissionAction).setPackage(context.packageName)
        val pending = PendingIntent.getBroadcast(
            context, requestCode, intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val receiver = object : BroadcastReceiver() {
            override fun onReceive(ctx: Context, received: Intent) {
                try { context.unregisterReceiver(this) } catch (_: IllegalArgumentException) { }
                val granted = received.getBooleanExtra(UsbManager.EXTRA_PERMISSION_GRANTED, false)
                onResult(granted && usb.hasPermission(device))
            }
        }
        val filter = IntentFilter(permissionAction)
        if (Build.VERSION.SDK_INT >= 33) context.registerReceiver(receiver, filter, Context.RECEIVER_NOT_EXPORTED)
        else context.registerReceiver(receiver, filter)
        usb.requestPermission(device, pending)
        return true
    }

    fun report(): String {
        val devices = scan()
        if (devices.isEmpty()) return "Nenhum dispositivo USB conectado. Conecte um dongle de TV compatível via OTG."
        return buildString {
            append("DIAGNÓSTICO DE TV USB\n\n")
            devices.forEach { d ->
                append(if (d.likelyTuner) "• Possível dispositivo de vídeo/tuner" else "• Dispositivo USB")
                append("\n  ").append(d.deviceName)
                append("\n  VID=%04X PID=%04X".format(d.vendorId, d.productId))
                append("\n  Interfaces: ").append(d.interfaceCount)
                d.interfaces.forEach { i ->
                    append("\n    #").append(i.number).append(" ").append(i.classLabel)
                        .append(" (classe=0x%02X sub=0x%02X protocolo=0x%02X)".format(i.interfaceClass, i.subclass, i.protocol))
                }
                append("\n  Permissão Android: ").append(d.hasPermission)
                append("\n  Catálogo de chipsets: ").append(TvUsbChipsetCatalog.describe(d.vendorId, d.productId)).append("\n")
                if (d.vendorId == It9175Adapter.VENDOR_ID && d.productId == It9175Adapter.PRODUCT_ID) {
                    val device = usb.deviceList[d.deviceName]
                    if (device != null) {
                        val probe = It9175Adapter.probe(device, d.hasPermission)
                        append("\n  ADAPTADOR IT9175: ").append(probe.state)
                        append("\n  Etapas: ").append(probe.stages.joinToString(" → "))
                        probe.messages.forEach { append("\n    - ").append(it) }
                        probe.endpoints.forEach { endpoint ->
                            append("\n    Endpoint IF#").append(endpoint.interfaceIndex)
                                .append(" addr=0x%02X".format(endpoint.endpointAddress))
                                .append(" ").append(endpoint.direction).append("/").append(endpoint.transferType)
                                .append(" maxPacket=").append(endpoint.maxPacketSize)
                        }
                    }
                }
                append("\n  ").append(d.notes).append("\n\n")
            }
            append("A permissão USB apenas libera comunicação com o dispositivo. A recepção ao vivo ainda exige driver/protocolo do chipset, demodulador, padrão regional e decodificador compatíveis.")
        }
    }
}
