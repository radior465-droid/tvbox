package br.com.fmdx.android.control

import br.com.fmdx.android.integration.LiveStatusSnapshot
import br.com.fmdx.android.integration.CapabilityStatus

data class ControlCenterState(
    val live: LiveStatusSnapshot,
    val capabilities: List<CapabilityStatus>,
    val recentEvents: List<String>
)
