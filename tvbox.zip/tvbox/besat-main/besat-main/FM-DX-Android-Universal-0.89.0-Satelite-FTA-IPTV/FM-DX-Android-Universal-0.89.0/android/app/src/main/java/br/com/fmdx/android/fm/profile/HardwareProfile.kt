package br.com.fmdx.android.fm.profile

import br.com.fmdx.android.fm.evidence.Evidence

data class HardwareProfile(
    val manufacturer: String,
    val model: String,
    val platform: String,
    val androidVersion: String,
    val evidence: List<Evidence>,
    val confidenceScore: Int,
    val recommendedMode: String
)
