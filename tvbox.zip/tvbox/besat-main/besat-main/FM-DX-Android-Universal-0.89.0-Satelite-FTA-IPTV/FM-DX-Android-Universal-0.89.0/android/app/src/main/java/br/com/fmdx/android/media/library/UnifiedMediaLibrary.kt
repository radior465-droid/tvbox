package br.com.fmdx.android.media.library

data class LibraryEntry(
    val id: String,
    val title: String,
    val source: String,
    val kind: String,
    val favorite: Boolean = false,
    val lastPositionMs: Long = 0L
)

object UnifiedMediaLibrary {
    fun search(entries: List<LibraryEntry>, query: String): List<LibraryEntry> {
        val q = query.trim()
        if (q.isEmpty()) return entries
        return entries.filter {
            it.title.contains(q, true) || it.source.contains(q, true) || it.kind.contains(q, true)
        }
    }

    fun favorites(entries: List<LibraryEntry>) = entries.filter { it.favorite }

    fun resumable(entries: List<LibraryEntry>) = entries.filter { it.lastPositionMs > 0L }
}
