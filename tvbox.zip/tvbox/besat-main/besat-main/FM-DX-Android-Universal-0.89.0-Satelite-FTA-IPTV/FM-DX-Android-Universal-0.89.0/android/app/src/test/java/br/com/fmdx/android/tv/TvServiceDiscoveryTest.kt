package br.com.fmdx.android.tv

import org.junit.Assert.*
import org.junit.Test

class TvServiceDiscoveryTest {
    private fun withCrc(body: ByteArray): ByteArray {
        val crc = MpegPsiCrc32.calculate(body)
        return body + byteArrayOf((crc ushr 24).toByte(), (crc ushr 16).toByte(), (crc ushr 8).toByte(), crc.toByte())
    }

    private fun packet(pid: Int, cc: Int, section: ByteArray): ByteArray {
        val out = ByteArray(188) { 0xFF.toByte() }
        out[0] = 0x47
        out[1] = (0x40 or ((pid shr 8) and 0x1F)).toByte()
        out[2] = pid.toByte()
        out[3] = (0x10 or (cc and 0x0F)).toByte()
        out[4] = 0 // pointer_field
        section.copyInto(out, 5)
        return out
    }

    private fun pat(): ByteArray = withCrc(byteArrayOf(
        0x00, 0xB0.toByte(), 0x0D, 0x00, 0x01, 0xC1.toByte(), 0, 0,
        0x00, 0x01, 0xE1.toByte(), 0x00
    ))

    private fun pmt(): ByteArray = withCrc(byteArrayOf(
        0x02, 0xB0.toByte(), 0x12, 0x00, 0x01, 0xC1.toByte(), 0, 0,
        0xE1.toByte(), 0x01, 0xF0.toByte(), 0,
        0x1B, 0xE1.toByte(), 0x01, 0xF0.toByte(), 0
    ))

    @Test fun validatesMpegPsiCrc() {
        val valid = pat()
        assertTrue(MpegPsiCrc32.isValidSection(valid))
        valid[9] = (valid[9].toInt() xor 1).toByte()
        assertFalse(MpegPsiCrc32.isValidSection(valid))
    }

    @Test fun discoversProgramOnlyAfterMatchingPatAndPmt() {
        val discovery = TvServiceDiscovery()
        val afterPat = discovery.feed(packet(0, 0, pat()))
        assertTrue(afterPat.patValid)
        assertEquals(1, afterPat.programsExpected)
        assertTrue(afterPat.services.isEmpty())

        val afterPmt = discovery.feed(packet(0x100, 0, pmt()))
        assertEquals(1, afterPmt.services.size)
        val service = afterPmt.services.single()
        assertEquals(1, service.programNumber)
        assertEquals(0x100, service.pmtPid)
        assertEquals(listOf(0x101), service.videoPids)
        assertTrue(service.audioPids.isEmpty())
    }

    @Test fun rejectsCorruptPatInsteadOfPublishingPrograms() {
        val bad = pat().also { it[it.lastIndex] = (it.last().toInt() xor 1).toByte() }
        val snapshot = TvServiceDiscovery().feed(packet(0, 0, bad))
        assertFalse(snapshot.patValid)
        assertEquals(0, snapshot.programsExpected)
        assertEquals(1, snapshot.rejectedPsiSections)
    }
}
