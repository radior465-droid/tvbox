package br.com.fmdx.android

import android.app.Activity
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.graphics.Color
import android.view.View
import android.view.ViewGroup
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.*
import android.net.Uri
import android.content.Intent
import android.os.Build
import br.com.fmdx.android.playback.BackgroundAudioService
import br.com.fmdx.android.playback.StreamUrlValidator
import br.com.fmdx.android.video.VideoProfileStore
import br.com.fmdx.android.video.VideoSource
import br.com.fmdx.android.video.VideoSourceDetector
import br.com.fmdx.android.tv.UsbTvReceiverDiscovery
import br.com.fmdx.android.tv.TvChannel
import br.com.fmdx.android.tv.TvChannelStore
import br.com.fmdx.android.tv.TvHistoryStore
import br.com.fmdx.android.media.SmartMediaEngine
import br.com.fmdx.android.media.UniversalMediaHub
import br.com.fmdx.android.ui.SignalMeterView
import br.com.fmdx.android.control.RealTimeControlCenter
import br.com.fmdx.android.fm.FmHardwareManager
import br.com.fmdx.android.fm.database.HardwareSignatureDatabase
import br.com.fmdx.android.fm.dsp.StationProfile
import br.com.fmdx.android.fm.dsp.StationProfileStore
import br.com.fmdx.android.rf.VirtualRfLab
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import kotlin.concurrent.thread

class MainActivity : Activity() {
    // O endereço pode ser configurado na tela inicial e fica salvo no aparelho.
    private val DEFAULT_DIRECTORY_API = ""
    private val prefs by lazy { getSharedPreferences("fmdx", MODE_PRIVATE) }
    private lateinit var root: LinearLayout
    private lateinit var status: TextView
    private var web: WebView? = null
    private val bg = Color.rgb(8, 21, 34)
    private val panel = Color.rgb(19, 43, 64)
    private val cyan = Color.rgb(53, 182, 232)
    private val white = Color.WHITE
    private val fmHardwareManager by lazy { FmHardwareManager(applicationContext) }
    private val usbTvDiscovery by lazy { UsbTvReceiverDiscovery(applicationContext) }
    private var lanRadioBridge: br.com.fmdx.android.integration.LanRadioBridge? = null
    private val rfHandler = Handler(Looper.getMainLooper())
    private var rfAnimation: Runnable? = null
    private var rfGraphView: br.com.fmdx.android.rf.SpectrumGraphView? = null

    override fun onDestroy() {
        stopRfAnimation()
        lanRadioBridge?.close()
        lanRadioBridge = null
        super.onDestroy()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        showHome()
    }

    private fun base(title: String): LinearLayout {
        root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(22, 24, 22, 18); setBackgroundColor(bg) }
        val heading = TextView(this).apply { text = title; textSize = 25f; setTextColor(white); setPadding(0, 4, 0, 6); typeface = android.graphics.Typeface.DEFAULT_BOLD }
        root.addView(heading)
        status = TextView(this).apply { text = "FM-DX • Rádio definida por software"; textSize = 13f; setTextColor(0xFF9EB8CC.toInt()); setPadding(0, 0, 0, 18) }
        root.addView(status)
        return root
    }

    private fun button(label: String, action: () -> Unit): Button = Button(this).apply {
        text = label; setTextColor(white); setBackgroundTintList(android.content.res.ColorStateList.valueOf(panel));
        setOnClickListener { action() }
    }

    private fun addField(hint: String, value: String = ""): EditText = EditText(this).apply {
        this.hint = hint; setText(value); setHintTextColor(0xFF8EA7BA.toInt()); setTextColor(white)
        textSize = 15f; setSingleLine(true); setPadding(14, 8, 14, 8)
        backgroundTintList = android.content.res.ColorStateList.valueOf(cyan)
    }

    private fun section(title: String) = TextView(this).apply {
        text = title
        textSize = 13f
        setTextColor(cyan)
        typeface = android.graphics.Typeface.DEFAULT_BOLD
        setPadding(0, 22, 0, 8)
    }

    private fun homeCard(title: String, description: String, action: () -> Unit): LinearLayout {
        return LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(20, 16, 20, 16)
            setBackgroundColor(panel)
            val t = TextView(this@MainActivity).apply { text = title; textSize = 18f; setTextColor(white); typeface = android.graphics.Typeface.DEFAULT_BOLD }
            val d = TextView(this@MainActivity).apply { text = description; textSize = 13f; setTextColor(0xFFB7C9D8.toInt()); setPadding(0, 6, 0, 0) }
            addView(t); addView(d)
            setOnClickListener { action() }
        }
    }


    private fun showIsdbtEpg() {
        val layout = base("GUIA DE PROGRAMAÇÃO • EPG")
        val intro = TextView(this).apply {
            text = "Grade de programação ISDB-T / SBTVD\nOs horários recebidos no fluxo SI são convertidos para o fuso local do aparelho."
            textSize = 14f; setTextColor(0xFFB7C9D8.toInt()); setPadding(0, 4, 0, 14)
        }
        layout.addView(intro)
        val emptyPanel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(18, 18, 18, 18); setBackgroundColor(panel)
        }
        emptyPanel.addView(TextView(this).apply {
            text = "AGUARDANDO DADOS DE PROGRAMAÇÃO"
            textSize = 16f; typeface = android.graphics.Typeface.DEFAULT_BOLD; setTextColor(cyan)
        })
        emptyPanel.addView(TextView(this).apply {
            text = "O decodificador já organiza serviços e eventos EIT em uma grade por canal. Para preencher esta tela é necessário que um receptor/driver compatível forneça as seções SI reais. Nenhum programa fictício será exibido."
            textSize = 14f; setTextColor(white); setPadding(0, 10, 0, 0)
        })
        layout.addView(emptyPanel, matchWrap())
        layout.addView(section("DADOS QUE A GRADE EXIBIRÁ"))
        listOf("Emissora e identificador do serviço", "Horário inicial e duração", "Título do programa", "Sinopse / descrição disponível", "Ordenação cronológica por canal").forEach { item ->
            layout.addView(TextView(this).apply { text = "• $item"; textSize = 14f; setTextColor(white); setPadding(4, 7, 4, 7) })
        }
        layout.addView(button("← VOLTAR") { showHome() }, matchWrap())
        setContentView(layout)
    }

    private fun showHome() {
        stopRfAnimation()
        web = null
        val layout = base("FM-DX • RADIO & VIDEO")
        val subtitle = TextView(this).apply {
            text = "Central universal para Rádio FM, Vídeo, TV USB e diagnóstico de hardware"
            setTextColor(white); textSize = 16f; setPadding(0, 0, 0, 10)
        }
        layout.addView(subtitle)

        val livePanel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(20, 18, 20, 18)
            setBackgroundColor(panel)
        }
        val liveTitle = TextView(this).apply {
            text = "● PAINEL DO RECEPTOR"
            textSize = 14f; setTextColor(cyan); typeface = android.graphics.Typeface.DEFAULT_BOLD
        }
        val frequency = TextView(this).apply {
            text = "--.- MHz"
            textSize = 30f; setTextColor(white); typeface = android.graphics.Typeface.DEFAULT_BOLD
            setPadding(0, 10, 0, 4)
        }
        val liveStatus = TextView(this).apply {
            text = "Status: aguardando diagnóstico do backend FM"
            textSize = 13f; setTextColor(0xFFB7C9D8.toInt())
        }
        val meter = SignalMeterView(this).apply { level = 0; minimumHeight = 54 }
        livePanel.addView(liveTitle); livePanel.addView(frequency); livePanel.addView(liveStatus)
        livePanel.addView(meter, LinearLayout.LayoutParams(-1, 64))
        layout.addView(livePanel, matchWrap())

        val quick = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; setPadding(0, 12, 0, 0) }
        quick.addView(button("📻 FM") { showFmReceiver() }, LinearLayout.LayoutParams(0, -2, 1f))
        quick.addView(button("📺 VÍDEO") { showVideoHub() }, LinearLayout.LayoutParams(0, -2, 1f))
        layout.addView(quick, matchWrap())

        layout.addView(section("RECEPÇÃO E MULTIMÍDIA"))
        layout.addView(homeCard("📻 Meu Receptor FM", "Detecção, status e recursos do rádio nativo.") { showFmReceiver() }, matchWrap())
        layout.addView(homeCard("🧩 FM Driver Probe", "Procura evidências de backend/vendor FM já presente no aparelho.") { showFmDriverProbe() }, matchWrap())
        layout.addView(homeCard("📺 TV / Vídeo Universal", "Reproduza fontes de vídeo e gerencie canais salvos.") { showVideoHub() }, matchWrap())
        layout.addView(homeCard("📅 Guia de Programação EPG", "Grade por emissora, horários, títulos e sinopses recebidos via ISDB-T.") { showIsdbtEpg() }, matchWrap())
        layout.addView(homeCard("🔊 Áudio nativo em segundo plano", "Reproduza um fluxo de rádio com serviço Android e controles na notificação.") { showBackgroundAudio() }, matchWrap())
        layout.addView(homeCard("🧠 Universal Media Hub", "Central unificada para Rádio, TV/Vídeo, favoritos, histórico e dispositivos.") { showUniversalMediaHub() }, matchWrap())
        layout.addView(homeCard("🧠 Smart Media Center", "Classifica fontes e centraliza inteligência de mídia.") { showSmartMediaCenter() }, matchWrap())
        layout.addView(homeCard("🎛️ Real-Time Control Center", "Status, capacidades e eventos recentes em uma única tela.") { showRealTimeControlCenter() }, matchWrap())
        layout.addView(homeCard("🔌 TV USB / Diagnóstico", "Detecte dispositivos USB e verifique compatibilidade.") { showUsbTvDiagnostics() }, matchWrap())
        layout.addView(homeCard("🌐 Conectividade Universal", "Detecte Wi-Fi, rede móvel, Bluetooth, USB/OTG, Ethernet e NFC.") { showConnectivityCenter() }, matchWrap())
        layout.addView(homeCard("🛰️ Explorador SDR Mundial", "Mapas, diretórios públicos e abertura de uma URL SDR.") { showSdrExplorer() }, matchWrap())
        layout.addView(homeCard("📈 Laboratório Virtual de RF", "Gere sinais I/Q artificiais, execute FFT e visualize picos sem hardware.") { showVirtualRfLab() }, matchWrap())
        layout.addView(homeCard("🎛️ Rádio Virtual / DSP", "Perfis virtuais, sinais e análise DSP.") { showVirtualRadio() }, matchWrap())
        layout.addView(homeCard("💎 Rádio Híbrido / Cristal", "Diagnóstico experimental do ambiente de hardware.") { showHybridRadio() }, matchWrap())

        layout.addView(section("INTELIGÊNCIA E COMPATIBILIDADE"))
        layout.addView(homeCard("🧠 Motor Inteligente", "Decisão adaptativa baseada nas evidências disponíveis.") { showAdaptiveRadio() }, matchWrap())
        layout.addView(homeCard("📊 Relatório de Compatibilidade", "Histórico, compatibilidade e resultados locais.") { showCompatibilityReport() }, matchWrap())
        layout.addView(homeCard("🔬 Diagnóstico Universal", "Verificação geral do ambiente e do hardware.") { showUniversalDiagnostics() }, matchWrap())
        layout.addView(homeCard("🧪 Laboratório de Hardware", "Execute e consulte testes estruturados.") { showHardwareLab() }, matchWrap())

        layout.addView(section("SERVIDORES FM-DX"))
        val url = addField("Endereço do servidor (https://...)")
        layout.addView(url, matchWrap())
        val directory = addField("API do diretório (ex.: https://meuservidor.com/api)", prefs.getString("directory_api", DEFAULT_DIRECTORY_API) ?: DEFAULT_DIRECTORY_API)
        layout.addView(directory, matchWrap())
        layout.addView(button("SALVAR API DO DIRETÓRIO") {
            val api = normalizeApi(directory.text.toString())
            if (api == null) toast("Informe uma API http:// ou https:// válida")
            else { prefs.edit().putString("directory_api", api).apply(); toast("API do diretório salva") }
        }, matchWrap())
        layout.addView(button("CONECTAR AO SERVIDOR") {
            val address = normalize(url.text.toString())
            if (address == null) toast("Digite um endereço http:// ou https:// válido") else openServer(address)
        }, matchWrap())
        layout.addView(button("SERVIDORES PÚBLICOS") { loadDirectory(layout) }, matchWrap())
        layout.addView(button("MEUS SERVIDORES / CONVITES") { showSaved(layout) }, matchWrap())
        layout.addView(button("ADICIONAR AOS MEUS SERVIDORES") {
            val address = normalize(url.text.toString())
            if (address == null) toast("Informe um endereço válido") else { saveServer(address); toast("Endereço salvo") }
        }, matchWrap())
        val note = TextView(this).apply {
            text = "Dica: servidores privados não aparecem na lista pública. Use o endereço ou convite enviado pelo proprietário. O servidor FM-DX e o receptor precisam estar ligados."
            setTextColor(0xFF9EB8CC.toInt()); textSize = 13f; setPadding(0, 22, 0, 0)
        }
        layout.addView(note)
        setContentView(ScrollView(this).apply { addView(layout) })
    }







private fun stopRfAnimation() {
    rfAnimation?.let { rfHandler.removeCallbacks(it) }
    rfAnimation = null
}

private fun showVirtualRfLab() {
    stopRfAnimation()
    web = null
    val layout = base("LABORATÓRIO VIRTUAL DE RF")
    val intro = TextView(this).apply {
        text = "Modo demonstração: os sinais desta tela são gerados matematicamente pelo aplicativo. Não são transmissões captadas pelo celular e não representam ocupação real do espectro."
        setTextColor(white); textSize = 14f; setPadding(0, 8, 0, 14)
    }
    layout.addView(intro, matchWrap())
    val statusText = TextView(this).apply {
        text = "Pronto para gerar uma amostra I/Q sintética."
        setTextColor(cyan); textSize = 14f; setPadding(0, 8, 0, 12)
    }
    layout.addView(statusText, matchWrap())
    val graph = br.com.fmdx.android.rf.SpectrumGraphView(this).apply { minimumHeight = 260 }
    rfGraphView = graph
    layout.addView(graph, LinearLayout.LayoutParams(-1, 280))
    val resultBox = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(16, 14, 16, 14)
        setBackgroundColor(panel)
    }
    val summary = TextView(this).apply {
        text = "Nenhuma análise executada."
        setTextColor(white); textSize = 14f
    }
    resultBox.addView(summary)
    val peaksText = TextView(this).apply {
        text = ""
        setTextColor(0xFFB7C9D8.toInt()); textSize = 13f; setPadding(0, 12, 0, 0)
    }
    resultBox.addView(peaksText)
    layout.addView(resultBox, matchWrap())
    fun renderSyntheticFrame() {
        try {
            val (i, q) = VirtualRfLab.generate(seed = System.nanoTime())
            val spectrum = VirtualRfLab.analyze(i, q, 2_400_000.0, 100_000_000.0)
            graph.submitSpectrum(spectrum.levelsDb)
            summary.text = "Amostras I/Q: ${spectrum.samples}\nTaxa simulada: ${"%.2f".format(spectrum.sampleRateHz / 1_000_000.0)} MS/s\nCentro virtual: 100,000 MHz\nBins FFT: ${spectrum.levelsDb.size}\nPicos encontrados: ${spectrum.peaks.size}"
            peaksText.text = spectrum.peaks.take(6).mapIndexed { index, peak ->
                "${index + 1}. ${"%.3f".format(peak.frequencyHz / 1_000_000.0)} MHz  •  ${"%.1f".format(peak.levelDb)} dBFS"
            }.joinToString("\n").ifBlank { "Nenhum pico destacado." }
            statusText.text = "Espectro atualizado com dados sintéticos — não é recepção real."
        } catch (error: Exception) {
            statusText.text = "Falha na simulação: ${error.message ?: "erro desconhecido"}"
        }
    }
    layout.addView(button("GERAR UMA AMOSTRA E EXECUTAR FFT") { renderSyntheticFrame() }, matchWrap())
    layout.addView(button("INICIAR ESPECTRO ANIMADO") {
        stopRfAnimation()
        val task = object : Runnable {
            override fun run() {
                renderSyntheticFrame()
                rfHandler.postDelayed(this, 700L)
            }
        }
        rfAnimation = task
        task.run()
    }, matchWrap())
    layout.addView(button("PARAR ANIMAÇÃO") {
        stopRfAnimation()
        statusText.text = "Animação parada. Os dados exibidos são a última simulação."
    }, matchWrap())
    layout.addView(section("CENÁRIOS DE TESTE"))
    layout.addView(homeCard("Portadoras e ruído", "Três tons artificiais em diferentes posições do canal, com ruído determinístico por semente.") { })
    layout.addView(homeCard("Processamento I/Q", "Amostras complexas em banda-base processadas por FFT radix-2 e janela Hann.") { })
    layout.addView(homeCard("Limite do modo virtual", "Não detecta estações, canais de TV, redes móveis ou sinais do ambiente. Para isso é necessário hardware e integração compatíveis.") { })
    layout.addView(button("VOLTAR AO INÍCIO") { showHome() }, matchWrap())
    setContentView(ScrollView(this).apply { addView(layout) })
}

private fun showConnectivityCenter() {
    web = null
    val layout = base("UNIVERSAL CONNECTIVITY ENGINE")
    val intro = TextView(this).apply {
        text = "Diagnóstico somente de leitura. O FM-DX identifica os caminhos de comunicação disponíveis sem ativar rádios, alterar redes ou iniciar transmissões."
        setTextColor(white); textSize = 14f; setPadding(0, 10, 0, 12)
    }
    layout.addView(intro, matchWrap())
    br.com.fmdx.android.integration.UniversalConnectivityManager.snapshot(applicationContext).forEach { item ->
        layout.addView(homeCard("${item.name} • ${item.state}", item.detail) { })
    }
    layout.addView(section("PONTE ENTRE DOIS CELULARES • WI-FI / LAN"))
    val hostField = addField("IP do celular receptor (ex.: 192.168.1.20)")
    val tokenField = addField("Código compartilhado (4 a 32 caracteres)")
    val portField = addField("Porta", br.com.fmdx.android.integration.LanRadioBridge.DEFAULT_PORT.toString())
    layout.addView(TextView(this).apply {
        text = "No celular A, inicie o servidor e informe o IP exibido ao celular B. Nos dois aparelhos, use o mesmo código. Ambos precisam estar na mesma rede Wi-Fi ou LAN."
        setTextColor(white); textSize = 13f; setPadding(0, 4, 0, 10)
    })
    layout.addView(hostField, matchWrap())
    layout.addView(tokenField, matchWrap())
    layout.addView(portField, matchWrap())
    val peerStatus = TextView(this).apply {
        text = "Ponte parada. O tráfego funciona apenas na rede local."
        setTextColor(cyan); textSize = 14f; setPadding(0, 12, 0, 12)
    }
    layout.addView(peerStatus, matchWrap())
    fun bridge(): br.com.fmdx.android.integration.LanRadioBridge {
        return lanRadioBridge ?: br.com.fmdx.android.integration.LanRadioBridge(object : br.com.fmdx.android.integration.LanRadioBridge.Listener {
            override fun onStatus(message: String) { runOnUiThread { peerStatus.text = message } }
            override fun onMetadata(metadata: JSONObject) { runOnUiThread { peerStatus.text = "Metadados recebidos: ${metadata.optString("frequencyMHz", "frequência não informada")} MHz • RDS ${metadata.optString("rds", "—")}" } }
            override fun onAudioFrame(pcm: ByteArray) { runOnUiThread { peerStatus.text = "Áudio recebido: ${pcm.size} bytes PCM (quadro)." } }
        }).also { lanRadioBridge = it }
    }
    layout.addView(button("INICIAR SERVIDOR NESTE CELULAR") {
        val token = tokenField.text.toString().trim()
        val port = portField.text.toString().toIntOrNull()
        if (token.length !in 4..32 || port == null || port !in 1024..65535) toast("Confira código e porta (1024–65535)")
        else {
            try {
                bridge().startServer(token, port)
                peerStatus.text = "Servidor iniciado. IP local: ${bridge().localIpv4() ?: "consulte os detalhes do Wi-Fi"} • porta $port"
            } catch (e: Exception) { toast("Não foi possível iniciar: ${e.message}") }
        }
    }, matchWrap())
    layout.addView(button("CONECTAR A OUTRO CELULAR") {
        val host = hostField.text.toString().trim()
        val token = tokenField.text.toString().trim()
        val port = portField.text.toString().toIntOrNull()
        if (host.isBlank() || token.length !in 4..32 || port == null || port !in 1024..65535) toast("Informe IP, código e porta válidos")
        else bridge().connect(host, port, token)
    }, matchWrap())
    layout.addView(button("ENVIAR TESTE DE METADADOS FM / RDS") {
        bridge().publishMetadata(JSONObject().put("frequencyMHz", "99.5").put("rds", "FM-DX TEST").put("stationName", "TESTE DE REDE").put("timestamp", System.currentTimeMillis()))
        toast("Metadados de teste enviados se houver conexão")
    }, matchWrap())
    layout.addView(button("DESCONECTAR") { lanRadioBridge?.stop() }, matchWrap())
    layout.addView(TextView(this).apply {
        text = "Áudio: o protocolo já aceita quadros PCM por publishAudio(), mas a captura do áudio real do sintonizador ainda precisa ser ligada a um backend autorizado. O botão de teste envia somente metadados fictícios, não áudio FM. O código compartilhado é uma barreira básica de pareamento, não criptografia; use apenas em rede confiável."
        setTextColor(0xFFFFD28A.toInt()); textSize = 12f; setPadding(0, 12, 0, 8)
    }, matchWrap())
    layout.addView(section("PRÓXIMAS INTEGRAÇÕES"))
    layout.addView(TextView(this).apply {
        text = "• Descoberta local entre celulares por Wi-Fi\n• Ponte de áudio e metadados RDS\n• Integração Bluetooth com acessórios\n• Protocolo USB para receptores SDR/FM compatíveis\n\nA detecção de conexão não significa que o aparelho tenha um sintonizador FM acessível. Cada receptor externo ainda precisa de driver/protocolo específico."
        setTextColor(white); textSize = 14f; setPadding(0, 4, 0, 12)
    })
    layout.addView(button("ATUALIZAR DIAGNÓSTICO") { showConnectivityCenter() }, matchWrap())
    layout.addView(button("VOLTAR") { showHome() }, matchWrap())
    setContentView(ScrollView(this).apply { addView(layout) })
}

private fun showFmDriverProbe() {
    web = null
    val layout = base("FM DRIVER PROBE")
    val result = TextView(this).apply {
        text = fmHardwareManager.fmDriverProbeReport()
        setTextColor(white); textSize = 14f; setPadding(0, 12, 0, 12)
    }
    layout.addView(result, matchWrap())
    layout.addView(button("EXECUTAR NOVAMENTE") { showFmDriverProbe() }, matchWrap())
    layout.addView(button("VOLTAR") { showHome() }, matchWrap())
    setContentView(ScrollView(this).apply { addView(layout) })
}

private fun showRealTimeControlCenter() {
    web = null
    val layout = base("REAL-TIME CONTROL CENTER")
    val state = RealTimeControlCenter.snapshot(applicationContext)

    layout.addView(section("STATUS AO VIVO"))
    fun statusLine(label: String, value: String) = TextView(this).apply {
        text = "$label: $value"
        textSize = 15f
        setTextColor(white)
        setPadding(0, 8, 0, 8)
    }
    layout.addView(statusLine("📻 FM", state.live.fm))
    layout.addView(statusLine("📺 VÍDEO", state.live.video))
    layout.addView(statusLine("🔌 USB", state.live.usb))
    layout.addView(statusLine("🧠 INTELLIGENCE", state.live.intelligence))
    layout.addView(statusLine("🔬 DIAGNÓSTICO", state.live.diagnostics))

    layout.addView(section("CAPACIDADES"))
    state.capabilities.forEach { capability ->
        layout.addView(homeCard(capability.title, "${capability.state} • ${capability.detail}") { })
    }

    layout.addView(section("EVENTOS RECENTES"))
    if (state.recentEvents.isEmpty()) {
        layout.addView(statusLine("Eventos", "Nenhum evento registrado ainda."))
    } else {
        state.recentEvents.forEach { event -> layout.addView(statusLine("•", event)) }
    }
    layout.addView(button("ATUALIZAR PAINEL") { showRealTimeControlCenter() }, matchWrap())
    layout.addView(button("VOLTAR") { showHome() }, matchWrap())
    setContentView(ScrollView(this).apply { addView(layout) })
}

    private fun showUniversalMediaHub() {
        web = null
        val layout = base("UNIVERSAL MEDIA HUB")
        val intro = TextView(this).apply {
            text = "Central de navegação da versão 0.28.0. O Hub organiza os módulos existentes; disponibilidade de hardware continua sendo verificada separadamente."
            setTextColor(white); textSize = 14f; setPadding(0, 12, 0, 12)
        }
        layout.addView(intro)
        UniversalMediaHub.items().forEach { item ->
            layout.addView(homeCard(item.title, item.subtitle) {
                when (item.section.name) {
                    "RADIO" -> showFmReceiver()
                    "TV_VIDEO" -> showVideoHub()
                    "FAVORITES" -> showChannelCenter()
                    "HISTORY" -> showChannelCenter()
                    "DEVICES" -> showUsbTvDiagnostics()
                    else -> showUniversalDiagnostics()
                }
            }, matchWrap())
        }
        layout.addView(button("← VOLTAR") { showHome() }, matchWrap())
        setContentView(ScrollView(this).apply { addView(layout) })
    }

    private fun showSmartMediaCenter() {
        web = null
        val layout = base("SMART MEDIA CENTER")
        val info = TextView(this).apply {
            text = "Central de mídia: organiza fontes sem assumir suporte inexistente de tuner ou codec. A classificação é baseada na URL e o funcionamento final depende do dispositivo."
            setTextColor(white); textSize = 14f; setPadding(0, 12, 0, 12)
        }
        layout.addView(info)
        layout.addView(button("📻 ABRIR RECEPTOR FM") { showFmReceiver() }, matchWrap())
        layout.addView(button("📺 ABRIR CENTRAL DE CANAIS") { showChannelCenter() }, matchWrap())
        val source = addField("Cole uma URL para classificação")
        layout.addView(source, matchWrap())
        val result = TextView(this).apply { setTextColor(cyan); textSize = 14f; setPadding(0, 12, 0, 12) }
        layout.addView(button("🧠 CLASSIFICAR FONTE") {
            val d = SmartMediaEngine.classify(source.text.toString().trim())
            result.text = "Tipo: ${d.kind} • confiança ${d.confidence}\n${d.note}"
        }, matchWrap())
        layout.addView(result)
        layout.addView(button("▶ CONTINUAR EM TV / VÍDEO") { showVideoHub() }, matchWrap())
        layout.addView(button("🔌 STATUS USB") { showUsbTvDiagnostics() }, matchWrap())
        layout.addView(button("← VOLTAR") { showHome() }, matchWrap())
        setContentView(ScrollView(this).apply { addView(layout) })
    }

    private fun showVideoHub() {
        web = null
        val layout = base("TV / Vídeo Universal")
        val info = TextView(this).apply {
            text = "Player experimental para fontes de vídeo autorizadas. MP4 e formatos suportados pelo Android podem tocar diretamente; HLS/DASH dependem do suporte do dispositivo/codec. Receptores de TV USB exigem driver compatível."
            setTextColor(white); textSize = 14f; setPadding(0, 12, 0, 12)
        }
        layout.addView(info)
        val name = addField("Nome do canal / vídeo")
        val url = addField("URL do vídeo/stream (http:// ou https://)")
        layout.addView(name, matchWrap()); layout.addView(url, matchWrap())
        layout.addView(button("REPRODUZIR") {
            val value = normalize(url.text.toString())
            if (value == null) toast("Informe uma URL válida") else playVideo(value, name.text.toString().ifBlank { "Vídeo" })
        }, matchWrap())
        layout.addView(button("📺 CENTRAL DE CANAIS") { showChannelCenter() }, matchWrap())
        layout.addView(button("SALVAR FONTE") {
            val value = normalize(url.text.toString())
            if (value == null) toast("Informe uma URL válida") else {
                VideoProfileStore(this).save(VideoSource(value, name.text.toString().ifBlank { "Fonte de vídeo" }, VideoSourceDetector.detect(value)))
                toast("Fonte salva")
            }
        }, matchWrap())
        val saved = VideoProfileStore(this).load()
        if (saved.isNotEmpty()) {
            layout.addView(TextView(this).apply { text="FONTES SALVAS"; setTextColor(cyan); setPadding(0,14,0,6) })
            saved.forEach { source -> layout.addView(button("▶ ${source.label} • ${source.type}") { playVideo(source.url, source.label) }, matchWrap()) }
        }
        layout.addView(button("← VOLTAR") { showHome() }, matchWrap())
        setContentView(ScrollView(this).apply { addView(layout) })
    }

    private fun playVideo(url: String, title: String) {
        web = null
        val shell = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(16,16,16,16); setBackgroundColor(bg) }
        val header = TextView(this).apply {
            text = "▶ AGORA REPRODUZINDO\n$title"
            setTextColor(white); textSize = 20f; typeface = android.graphics.Typeface.DEFAULT_BOLD
            setPadding(0,0,0,8)
        }
        val sourceInfo = TextView(this).apply {
            text = "Fonte: ${VideoSourceDetector.detect(url)} • URL configurada pelo usuário"
            setTextColor(0xFFB7C9D8.toInt()); textSize = 12f; setPadding(0,0,0,10)
        }
        val playerStatus = TextView(this).apply {
            text = "Status: preparando reprodução…"
            setTextColor(cyan); textSize = 13f; setPadding(0,0,0,8)
        }
        shell.addView(header); shell.addView(sourceInfo); shell.addView(playerStatus)
        val video = VideoView(this)
        val controller = MediaController(this); controller.setAnchorView(video); video.setMediaController(controller)
        video.setVideoURI(Uri.parse(url))
        video.setOnPreparedListener { media ->
            media.isLooping = false
            playerStatus.text = "Status: reproduzindo"
            video.start()
        }
        video.setOnCompletionListener { playerStatus.text = "Status: reprodução concluída" }
        video.setOnErrorListener { _, _, _ ->
            playerStatus.text = "Status: erro de reprodução / formato não suportado"
            toast("Não foi possível reproduzir esta fonte neste dispositivo")
            true
        }
        shell.addView(video, LinearLayout.LayoutParams(-1, 0, 1f))
        val controls = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; setPadding(0,10,0,0) }
        controls.addView(button("⏮ REINICIAR") { video.seekTo(0); video.start(); playerStatus.text = "Status: reproduzindo" }, LinearLayout.LayoutParams(0,-2,1f))
        controls.addView(button("⛶ TELA CHEIA") {
            window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_FULLSCREEN or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
            toast("Modo imersivo ativado. Toque/gestos do sistema podem restaurar os controles.")
        }, LinearLayout.LayoutParams(0,-2,1f))
        shell.addView(controls, matchWrap())
        shell.addView(button("★ SALVAR / ATUALIZAR FAVORITO") {
            VideoProfileStore(this).save(VideoSource(url, title, VideoSourceDetector.detect(url)))
            toast("Fonte salva nos favoritos")
        }, matchWrap())
        shell.addView(button("← VOLTAR") { video.stopPlayback(); window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_VISIBLE; showVideoHub() }, matchWrap())
        setContentView(shell)
    }


    private fun showChannelCenter() {
        web = null
        val layout = base("TV Channel Center")
        val subtitle = TextView(this).apply {
            text = "Canais, favoritos, histórico e troca rápida. Adicione apenas fontes autorizadas."
            setTextColor(white); textSize = 14f; setPadding(0, 8, 0, 12)
        }
        layout.addView(subtitle)

        val store = TvChannelStore(this)
        val history = TvHistoryStore(this)
        val name = addField("Nome do canal")
        val url = addField("URL do canal/stream (http:// ou https://)")
        val category = addField("Categoria (ex.: Notícias, Música, Geral)", "Geral")
        layout.addView(name, matchWrap()); layout.addView(url, matchWrap()); layout.addView(category, matchWrap())

        layout.addView(button("＋ ADICIONAR CANAL") {
            val value = normalize(url.text.toString())
            if (value == null) toast("Informe uma URL válida")
            else {
                store.save(TvChannel(value, name.text.toString().ifBlank { "Canal" }, category.text.toString().ifBlank { "Geral" }))
                toast("Canal salvo"); showChannelCenter()
            }
        }, matchWrap())

        fun addChannelRow(channel: TvChannel) {
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; setPadding(0, 6, 0, 6) }
            val play = button("▶ ${channel.name}${if (channel.favorite) " ★" else ""}") {
                history.add(channel); playVideo(channel.url, channel.name)
            }
            row.addView(play, LinearLayout.LayoutParams(0, -2, 1f))
            row.addView(button(if (channel.favorite) "★" else "☆") {
                store.toggleFavorite(channel.url); showChannelCenter()
            }, LinearLayout.LayoutParams(-2, -2))
            row.addView(button("✕") { store.remove(channel.url); showChannelCenter() }, LinearLayout.LayoutParams(-2, -2))
            layout.addView(row, matchWrap())
        }

        val channels = store.load()
        layout.addView(section("TODOS OS CANAIS • ${channels.size}"))
        if (channels.isEmpty()) {
            layout.addView(TextView(this).apply { text = "Nenhum canal salvo."; setTextColor(0xFFB7C9D8.toInt()) })
        } else channels.forEach(::addChannelRow)

        val favorites = channels.filter { it.favorite }
        layout.addView(section("★ FAVORITOS • ${favorites.size}"))
        if (favorites.isEmpty()) layout.addView(TextView(this).apply { text = "Nenhum favorito."; setTextColor(0xFFB7C9D8.toInt()) })
        else favorites.forEach { c ->
            layout.addView(button("▶ ${c.name}") { history.add(c); playVideo(c.url, c.name) }, matchWrap())
        }

        val recent = history.load()
        layout.addView(section("🕘 HISTÓRICO RECENTE"))
        if (recent.isEmpty()) layout.addView(TextView(this).apply { text = "Nenhuma reprodução registrada."; setTextColor(0xFFB7C9D8.toInt()) })
        else recent.forEach { c ->
            layout.addView(button("↻ ${c.name}") { history.add(c); playVideo(c.url, c.name) }, matchWrap())
        }
        layout.addView(button("LIMPAR HISTÓRICO") { history.clear(); showChannelCenter() }, matchWrap())
        layout.addView(button("← VOLTAR") { showVideoHub() }, matchWrap())
        setContentView(ScrollView(this).apply { addView(layout) })
    }

    private fun showUsbTvDiagnostics() {
        web = null
        val layout = base("Receptor de TV USB / Diagnóstico")
        val report = TextView(this).apply { textSize = 14f; setTextColor(white); setPadding(0,18,0,18) }
        val scroll = ScrollView(this)
        val content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        fun refresh() {
            content.removeAllViews()
            report.text = usbTvDiscovery.report()
            content.addView(report, matchWrap())
            val devices = usbTvDiscovery.scan()
            devices.filter { !it.hasPermission }.forEach { device ->
                content.addView(button("🔐 SOLICITAR PERMISSÃO USB — VID %04X / PID %04X".format(device.vendorId, device.productId)) {
                    val requested = usbTvDiscovery.requestPermission(device.deviceName) { granted ->
                        toast(if (granted) "Permissão USB concedida. Isso não confirma suporte ao tuner." else "Permissão USB não concedida.")
                        showUsbTvDiagnostics()
                    }
                    if (!requested) toast("Dispositivo desconectado. Atualize a detecção.")
                }, matchWrap())
            }
        }
        refresh()
        scroll.addView(content); layout.addView(scroll, LinearLayout.LayoutParams(-1,0,1f))
        layout.addView(button("ATUALIZAR DETECÇÃO") { refresh() }, matchWrap())
        layout.addView(button("← VOLTAR") { showHome() }, matchWrap())
        setContentView(layout)
    }

    private fun showVirtualRadio() {
        web = null
        val layout = base("Rádio Virtual / DSP")
        val info = TextView(this).apply {
            text = "Motor virtual: perfis de estações e análise DSP de amostras autorizadas.\n\nNão substitui o tuner FM físico e não contorna restrições de captura de áudio do Android."
            textSize = 14f; setTextColor(white); setPadding(0, 12, 0, 12)
        }
        layout.addView(info)
        val frequency = addField("Frequência virtual em MHz (ex.: 96.1)")
        val label = addField("Nome da estação / perfil")
        layout.addView(frequency, matchWrap())
        layout.addView(label, matchWrap())
        val list = TextView(this).apply { setTextColor(white); textSize = 14f; setPadding(0, 14, 0, 14) }
        fun refresh() {
            val profiles = StationProfileStore(this).load()
            list.text = if (profiles.isEmpty()) "Nenhum perfil virtual salvo." else profiles.joinToString("\n") {
                "${it.frequencyKhz / 1000.0} MHz • ${it.label} • confiança ${it.confidence}% • ${it.source}"
            }
        }
        layout.addView(button("SALVAR PERFIL VIRTUAL") {
            val mhz = frequency.text.toString().trim().replace(',', '.').toDoubleOrNull()
            if (mhz == null || mhz <= 0) { toast("Digite uma frequência válida"); return@button }
            val name = label.text.toString().trim().ifBlank { "Perfil virtual" }
            StationProfileStore(this).save(StationProfile((mhz * 1000).toInt(), name, "MANUAL", 50, "Perfil criado no rádio virtual"))
            refresh(); toast("Perfil salvo")
        }, matchWrap())
        val scroll = ScrollView(this); scroll.addView(list)
        layout.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        refresh()
        layout.addView(button("← VOLTAR") { showHome() }, matchWrap())
        setContentView(layout)
    }

    private fun showAdaptiveRadio() {
        web = null
        val layout = base("Motor Inteligente / Decisão")
        val report = TextView(this).apply {
            text = fmHardwareManager.adaptiveRadioReport()
            textSize = 14f
            setTextColor(white)
            setPadding(0, 18, 0, 18)
        }
        val scroll = ScrollView(this)
        scroll.addView(report)
        layout.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        layout.addView(button("RECALCULAR DECISÃO") { showAdaptiveRadio() }, matchWrap())
        layout.addView(button("← VOLTAR") { showHome() }, matchWrap())
        setContentView(layout)
    }

    private fun showCompatibilityReport() {
        web = null
        val layout = base("Relatório / Compatibilidade")
        val report = TextView(this).apply {
            text = fmHardwareManager.compatibilityDeviceReport() + "\n\n" + fmHardwareManager.compatibilityHistoryReport()
            textSize = 14f
            setTextColor(white)
            setPadding(0, 18, 0, 18)
        }
        val scroll = ScrollView(this)
        scroll.addView(report)
        layout.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        layout.addView(button("ATUALIZAR E SALVAR TESTE") { showCompatibilityReport() }, matchWrap())
        layout.addView(button("LIMPAR HISTÓRICO LOCAL") { fmHardwareManager.clearCompatibilityHistory(); toast("Histórico local removido"); showCompatibilityReport() }, matchWrap())
        layout.addView(button("← VOLTAR") { showHome() }, matchWrap())
        setContentView(layout)
    }

    private fun showHardwareLab() {
        web = null
        val layout = base("Laboratório de Testes de Hardware")
        val report = TextView(this).apply {
            text = fmHardwareManager.hardwareLabHistory()
            textSize = 14f
            setTextColor(white)
            setPadding(0, 18, 0, 18)
        }
        val scroll = ScrollView(this)
        scroll.addView(report)
        layout.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        layout.addView(button("EXECUTAR E REGISTRAR TESTES") {
            report.text = fmHardwareManager.runHardwareLab()
            toast("Testes registrados localmente")
        }, matchWrap())
        layout.addView(button("LIMPAR RESULTADO") {
            fmHardwareManager.clearHardwareLabHistory()
            report.text = fmHardwareManager.hardwareLabHistory()
        }, matchWrap())
        layout.addView(section("COMPARTILHAMENTO COLABORATIVO (OPCIONAL)"))
        layout.addView(TextView(this).apply {
            text = "Os relatórios ficam no aparelho. Ao exportar, o app remove o fingerprint exclusivo do firmware e não inclui número de série, conta ou localização. Nada é enviado automaticamente."
            setTextColor(white); textSize = 13f; setPadding(0, 4, 0, 10)
        })
        layout.addView(button("EXPORTAR RELATÓRIO ANONIMIZADO") {
            val json = HardwareSignatureDatabase(applicationContext).exportCommunityReport()
            val send = android.content.Intent(android.content.Intent.ACTION_SEND).apply {
                type = "application/json"
                putExtra(android.content.Intent.EXTRA_SUBJECT, "FM-DX — Relatório comunitário de compatibilidade")
                putExtra(android.content.Intent.EXTRA_TEXT, json)
            }
            startActivity(android.content.Intent.createChooser(send, "Compartilhar relatório FM-DX"))
        }, matchWrap())
        layout.addView(button("IMPORTAR RELATÓRIO DE OUTRO APARELHO") {
            val input = EditText(this).apply { hint = "Cole aqui o JSON recebido"; minLines = 5; gravity = android.view.Gravity.TOP; setTextColor(white) }
            android.app.AlertDialog.Builder(this)
                .setTitle("Importar relatório comunitário")
                .setMessage("A importação grava as observações neste aparelho. Não execute conteúdo recebido como código; somente JSON FM-DX será aceito.")
                .setView(input)
                .setNegativeButton("CANCELAR", null)
                .setPositiveButton("IMPORTAR") { _, _ ->
                    val outcome = runCatching { HardwareSignatureDatabase(applicationContext).importCommunityReport(input.text.toString()) }
                    outcome.onSuccess { count -> toast("$count observação(ões) nova(s) importada(s)"); report.text = fmHardwareManager.hardwareLabHistory() }
                        .onFailure { toast("Falha na importação: ${it.message ?: "relatório inválido"}") }
                }.show()
        }, matchWrap())
        layout.addView(button("← VOLTAR") { showHome() }, matchWrap())
        setContentView(layout)
    }

    private fun showEvidenceMatrix() {
        web = null
        val layout = base("Matriz de Evidências")
        val report = TextView(this).apply {
            text = fmHardwareManager.evidenceMatrixReport()
            textSize = 14f
            setTextColor(white)
            setPadding(0, 18, 0, 18)
        }
        val scroll = ScrollView(this)
        scroll.addView(report)
        layout.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        layout.addView(button("RECALCULAR MATRIZ") { showEvidenceMatrix() }, matchWrap())
        layout.addView(button("← VOLTAR") { showHome() }, matchWrap())
        setContentView(layout)
    }

    private fun showStructuredTestRunner() {
        web = null
        val layout = base("Test Runner Estruturado")
        val report = TextView(this).apply {
            text = fmHardwareManager.structuredTestHistory()
            textSize = 14f
            setTextColor(white)
            setPadding(0, 18, 0, 18)
        }
        val scroll = ScrollView(this)
        scroll.addView(report)
        layout.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        layout.addView(button("EXECUTAR SEQUÊNCIA DE TESTES") {
            report.text = fmHardwareManager.runStructuredTests()
            toast("Sequência concluída e registrada localmente")
        }, matchWrap())
        layout.addView(button("LIMPAR HISTÓRICO") {
            fmHardwareManager.clearStructuredTestHistory()
            report.text = fmHardwareManager.structuredTestHistory()
        }, matchWrap())
        layout.addView(button("← VOLTAR") { showHome() }, matchWrap())
        setContentView(layout)
    }

    private fun showCompatibilityTimeline() {
        web = null
        val layout = base("Linha do Tempo / Compatibilidade")
        val report = TextView(this).apply {
            text = fmHardwareManager.compatibilityTimelineReport()
            textSize = 14f
            setTextColor(white)
            setPadding(0, 18, 0, 18)
        }
        val scroll = ScrollView(this)
        scroll.addView(report)
        layout.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        layout.addView(button("ATUALIZAR LINHA DO TEMPO") { report.text = fmHardwareManager.compatibilityTimelineReport() }, matchWrap())
        layout.addView(button("← VOLTAR") { showHome() }, matchWrap())
        setContentView(layout)
    }

    private fun showHybridRadio() {
        web = null
        val layout = base("Rádio Híbrido / Cristal")
        val report = TextView(this).apply {
            text = fmHardwareManager.hybridRadioReport()
            textSize = 14f
            setTextColor(white)
            setPadding(0, 18, 0, 18)
        }
        val scroll = ScrollView(this)
        scroll.addView(report)
        layout.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        layout.addView(button("ATUALIZAR ANÁLISE") { showHybridRadio() }, matchWrap())
        layout.addView(button("← VOLTAR") { showHome() }, matchWrap())
        setContentView(layout)
    }

    private fun showUniversalDiagnostics() {
        web = null
        val layout = base("Diagnóstico Universal")
        val report = TextView(this).apply {
            text = fmHardwareManager.universalDiagnosticReport()
            textSize = 14f
            setTextColor(white)
            setPadding(0, 18, 0, 18)
        }
        val scroll = ScrollView(this)
        scroll.addView(report)
        layout.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        layout.addView(button("ATUALIZAR DIAGNÓSTICO") { showUniversalDiagnostics() }, matchWrap())
        layout.addView(button("← VOLTAR") { showHome() }, matchWrap())
        setContentView(layout)
    }

    private fun showSamsungDiagnostics() {
        web = null
        val layout = base("Diagnóstico Samsung / Exynos")
        val report = TextView(this).apply {
            text = fmHardwareManager.samsungDiagnosticReport()
            textSize = 14f
            setTextColor(white)
            setPadding(0, 18, 0, 18)
        }
        val scroll = ScrollView(this)
        scroll.addView(report)
        layout.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        layout.addView(button("ATUALIZAR DIAGNÓSTICO") { showSamsungDiagnostics() }, matchWrap())
        layout.addView(button("← VOLTAR") { showHome() }, matchWrap())
        setContentView(layout)
    }

    private fun showFmReceiver() {
        web = null
        val layout = base("Meu Receptor FM")
        val info = TextView(this).apply {
            text = fmHardwareManager.report()
            textSize = 16f
            setTextColor(white)
            setPadding(0, 18, 0, 18)
        }
        layout.addView(info)
        val controller = fmHardwareManager.controller()
        val freq = addField("Frequência em MHz (ex.: 96.1)")
        layout.addView(freq, matchWrap())
        layout.addView(button("INICIAR RECEPTOR") {
            if (!controller.isSupported()) toast("Hardware FM ainda não suportado neste aparelho")
            else toast(if (controller.start()) "Receptor iniciado" else "Não foi possível iniciar o receptor")
        }, matchWrap())
        layout.addView(button("SINTONIZAR") {
            val mhz = freq.text.toString().trim().replace(',', '.').toDoubleOrNull()
            if (mhz == null) toast("Digite uma frequência válida")
            else if (!controller.tune((mhz * 1000).toInt())) toast("Sintonia não disponível neste backend")
            else toast("Sintonizado")
        }, matchWrap())
        layout.addView(button("SEEK ↑") {
            val found = controller.seekUp()
            if (found == null) toast("Busca automática não disponível neste backend") else { freq.setText(found / 1000.0); toast("Nova frequência encontrada") }
        }, matchWrap())
        layout.addView(button("SEEK ↓") {
            val found = controller.seekDown()
            if (found == null) toast("Busca automática não disponível neste backend") else { freq.setText(found / 1000.0); toast("Nova frequência encontrada") }
        }, matchWrap())
        layout.addView(button("PARAR RECEPTOR") { controller.stop(); toast("Receptor parado") }, matchWrap())
        layout.addView(button("← VOLTAR") { showHome() }, matchWrap())
        setContentView(layout)
    }

    private fun loadDirectory(layout: LinearLayout) {
        val directoryApi = prefs.getString("directory_api", DEFAULT_DIRECTORY_API)?.trim().orEmpty()
        if (directoryApi.isBlank()) { toast("Configure a API do diretório na tela inicial"); return }
        status.text = "Buscando servidores..."
        thread {
            try {
                val conn = (URL("$directoryApi/servers").openConnection() as HttpURLConnection).apply { connectTimeout = 8000; readTimeout = 8000 }
                val data = conn.inputStream.bufferedReader().use { it.readText() }; conn.disconnect()
                val arr = JSONArray(data)
                runOnUiThread {
                    layout.removeViews(3, (layout.childCount - 3).coerceAtLeast(0))
                    val label = TextView(this).apply { text = "SERVIDORES ENCONTRADOS: ${arr.length()}"; setTextColor(cyan); textSize = 15f; setPadding(0, 16, 0, 8) }
                    layout.addView(label)
                    for (i in 0 until arr.length()) {
                        val item = arr.getJSONObject(i); val name = item.optString("name", "Servidor FM-DX")
                        val info = listOf(item.optString("city"), item.optString("country")).filter { it.isNotBlank() }.joinToString(" • ")
                        layout.addView(button("$name\n$info") { openServer(item.getString("url")) }, matchWrap())
                    }
                    status.text = "Diretório público atualizado"
                }
            } catch (e: Exception) { runOnUiThread { status.text = "Não foi possível acessar o diretório"; toast(e.message ?: "Erro de conexão") } }
        }
    }

    private fun showSaved(layout: LinearLayout) {
        val arr = JSONArray(prefs.getString("servers", "[]"))
        layout.addView(TextView(this).apply { text = "SERVIDORES SALVOS"; setTextColor(cyan); textSize = 15f; setPadding(0, 14, 0, 8) })
        for (i in 0 until arr.length()) {
            val address = arr.optString(i)
            layout.addView(button(address) { openServer(address) }, matchWrap())
        }
        if (arr.length() == 0) toast("Nenhum servidor salvo ainda")
    }

    private fun saveServer(address: String) {
        val old = JSONArray(prefs.getString("servers", "[]")); val next = JSONArray()
        for (i in 0 until old.length()) if (old.optString(i) != address) next.put(old.optString(i))
        next.put(address); prefs.edit().putString("servers", next.toString()).apply()
    }

    private fun showBackgroundAudio() {
        web = null
        val layout = base("ÁUDIO NATIVO EM SEGUNDO PLANO")
        val info = TextView(this).apply {
            text = "Este reprodutor nativo mantém um fluxo de áudio independente do navegador e oferece controles na notificação. Compatibilidade depende do formato, servidor e rede. Vídeo/TV continuam na tela; este serviço é somente para áudio."
            setTextColor(white); textSize = 14f; setPadding(0, 8, 0, 14)
        }
        layout.addView(info, matchWrap())
        val titleField = addField("Nome da rádio (opcional)", "Rádio FM-DX")
        val urlField = addField("URL direta do fluxo HTTP/HTTPS")
        layout.addView(titleField, matchWrap())
        layout.addView(urlField, matchWrap())
        layout.addView(button("▶ INICIAR ÁUDIO EM SEGUNDO PLANO") {
            val stream = StreamUrlValidator.normalize(urlField.text.toString())
            if (stream == null) {
                toast("Informe uma URL direta HTTP ou HTTPS válida, sem usuário/senha embutidos")
            } else {
                val intent = Intent(this, BackgroundAudioService::class.java).apply {
                    action = BackgroundAudioService.ACTION_PLAY
                    putExtra(BackgroundAudioService.EXTRA_URL, stream)
                    putExtra(BackgroundAudioService.EXTRA_TITLE, titleField.text.toString().ifBlank { "Rádio FM-DX" })
                }
                try {
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) startForegroundService(intent) else startService(intent)
                    toast("Serviço de áudio solicitado. Verifique a notificação do FM-DX.")
                } catch (e: Exception) { toast("Não foi possível iniciar o serviço: ${e.message ?: "erro do Android"}") }
            }
        }, matchWrap())
        layout.addView(button("⏸ PAUSAR") { startService(Intent(this, BackgroundAudioService::class.java).setAction(BackgroundAudioService.ACTION_PAUSE)) }, matchWrap())
        layout.addView(button("▶ RETOMAR") { startService(Intent(this, BackgroundAudioService::class.java).setAction(BackgroundAudioService.ACTION_RESUME)) }, matchWrap())
        layout.addView(button("■ PARAR SERVIÇO") { startService(Intent(this, BackgroundAudioService::class.java).setAction(BackgroundAudioService.ACTION_STOP)); toast("Comando para parar enviado") }, matchWrap())
        layout.addView(button("← VOLTAR") { showHome() }, matchWrap())
        setContentView(ScrollView(this).apply { addView(layout) })
    }


    private fun showSdrExplorer() {
        web = null
        val layout = base("EXPLORADOR SDR MUNDIAL")
        val intro = TextView(this).apply {
            text = "Encontre receptores SDR públicos por mapas e diretórios. A faixa disponível depende de cada receptor; abrir um diretório não garante que todos os receptores estejam online."
            textSize = 14f; setTextColor(white); setPadding(0, 4, 0, 12)
        }
        layout.addView(intro)
        layout.addView(section("MAPAS E DIRETÓRIOS PÚBLICOS"))
        val sources = listOf(
            Triple("🌍 KiwiSDR — mapa mundial", "Receptores KiwiSDR e localização", "https://map.kiwisdr.com/"),
            Triple("📡 KiwiSDR — diretório", "Lista de receptores KiwiSDR públicos", "https://rx.kiwisdr.com/"),
            Triple("🗺️ ReceiverBook — OpenWebRX", "Mapa e catálogo de receptores OpenWebRX", "https://receiverbook.de/"),
            Triple("🌐 WebSDR.org", "Lista de servidores WebSDR independentes", "https://www.websdr.org/"),
            Triple("🗺️ RX-TX.info", "Mapa e lista de diferentes tecnologias SDR", "https://rx-tx.info/"),
            Triple("🌎 Mapa SDR comunitário", "Referências de KiwiSDR, OpenWebRX e WebSDR", "https://map-sdr.p00lack.cc/"),
            Triple("📻 Web-888", "Diretório e informações de receptores Web-888", "https://rx-888.com/"),
            Triple("🧭 Global SDR Atlas", "Lista comunitária de servidores SDR", "https://sdr.shbrg.nl/sdr/"),
            Triple("🌐 Live SDR Worldwide", "Diretório comunitário mundial", "https://kc4mcq.us/live-sdr/"),
            Triple("🔎 Global SDR Hub", "Portal de mapas e diretórios SDR", "https://pttradio.co.uk/global-sdr/"),
            Triple("📡 hams.live", "Referências de diretórios SDR", "https://hams.live/sdr/")
        )
        sources.forEach { (name, description, address) ->
            val card = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL; setPadding(14, 10, 14, 10); setBackgroundColor(panel)
                addView(TextView(this@MainActivity).apply { text = name; textSize = 16f; setTextColor(white); typeface = android.graphics.Typeface.DEFAULT_BOLD })
                addView(TextView(this@MainActivity).apply { text = description; textSize = 12f; setTextColor(0xFFB7C9D8.toInt()); setPadding(0, 3, 0, 0) })
                setOnClickListener { openExternalSdr(address) }
            }
            layout.addView(card, matchWrap())
        }
        layout.addView(section("ABRIR UMA URL SDR"))
        val addressField = addField("Cole a URL pública do KiwiSDR, OpenWebRX, WebSDR ou SpyServer")
        layout.addView(addressField, matchWrap())
        val analysis = TextView(this).apply {
            text = "Cole uma URL pública e toque em ANALISAR para identificar a plataforma e as faixas anunciadas."
            textSize = 13f; setTextColor(white); setPadding(12, 12, 12, 12); setBackgroundColor(panel)
        }
        layout.addView(button("ANALISAR URL SDR") {
            val address = normalize(addressField.text.toString())
            if (address == null) {
                toast("Informe uma URL http:// ou https:// válida")
            } else {
                analysis.text = "Analisando página pública…"
                thread {
                    val result = runCatching { SdrUrlAnalyzer.scan(address) }
                    runOnUiThread {
                        analysis.text = result.fold({ it.asText() }, { "Não foi possível analisar: ${it.message ?: "erro de conexão"}" })
                    }
                }
            }
        }, matchWrap())
        layout.addView(analysis, matchWrap())
        layout.addView(button("ABRIR RECEPTOR SDR") {
            val address = normalize(addressField.text.toString())
            if (address == null) toast("Informe uma URL http:// ou https:// válida")
            else openServer(address)
        }, matchWrap())
        val note = TextView(this).apply {
            text = "O scanner consulta somente a URL que você informar, limita a leitura da página, não segue redirecionamentos e bloqueia endereços locais/privados. As faixas são exibidas somente quando aparecem no conteúdo público da página; isso não confirma recepção nem disponibilidade contínua."
            textSize = 12f; setTextColor(0xFF9EB8CC.toInt()); setPadding(0, 8, 0, 14)
        }
        layout.addView(note)
        layout.addView(button("← VOLTAR") { showHome() }, matchWrap())
        setContentView(ScrollView(this).apply { addView(layout) })
    }

    private fun openExternalSdr(address: String) {
        try {
            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(address)))
        } catch (_: Exception) {
            toast("Não foi possível abrir o navegador")
        }
    }

    private fun openServer(address: String) {
        val view = WebView(this)
        web = view
        view.settings.javaScriptEnabled = true
        view.settings.domStorageEnabled = true
        view.settings.mediaPlaybackRequiresUserGesture = false
        // Ponte restrita a comandos de áudio com validação nativa de URL e tipo de mídia.
        view.addJavascriptInterface(br.com.fmdx.android.playback.NativeAudioJavascriptBridge(this), "FMDXNativeAudio")
        view.webChromeClient = WebChromeClient()
        view.webViewClient = object : WebViewClient() {
            override fun onPageFinished(v: WebView?, url: String?) { status.text = "Conectado: ${url ?: address}" }
        }
        val shell = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(bg) }
        shell.addView(button("← VOLTAR À LISTA") { view.stopLoading(); showHome() }, matchWrap())
        shell.addView(view, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(shell)
        view.loadUrl(address)
    }

    private fun normalizeApi(raw: String): String? {
        val value = normalize(raw) ?: return null
        return if (value.endsWith("/api")) value else "$value/api"
    }

    private fun normalize(raw: String): String? {
        val value = raw.trim().trimEnd('/')
        if (!value.startsWith("https://") && !value.startsWith("http://")) return null
        return try { val u = URL(value); if (u.host.isBlank()) null else value } catch (_: Exception) { null }
    }

    private fun matchWrap() = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { bottomMargin = 8 }
    private fun toast(message: String) = Toast.makeText(this, message, Toast.LENGTH_LONG).show()
    override fun onBackPressed() { if (web != null) { showHome() } else super.onBackPressed() }
}
