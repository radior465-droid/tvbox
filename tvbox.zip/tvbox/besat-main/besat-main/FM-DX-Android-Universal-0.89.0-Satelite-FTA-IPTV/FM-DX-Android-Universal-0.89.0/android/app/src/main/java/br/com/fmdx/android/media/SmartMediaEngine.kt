package br.com.fmdx.android.media

/**
 * Classifica fontes sem inventar capacidades de hardware.
 * A reprodução e o acesso ao tuner continuam dependentes do backend/driver real.
 */
enum class MediaKind { FM_NATIVE, VIDEO_FILE, HLS, DASH, WEB, UNKNOWN }

data class MediaDecision(
    val kind: MediaKind,
    val confidence: String,
    val note: String
)

object SmartMediaEngine {
    fun classify(source: String): MediaDecision {
        val s = source.lowercase()
        return when {
            s.endsWith(".m3u8") || s.contains(".m3u8?") -> MediaDecision(MediaKind.HLS, "alta", "Fluxo HLS detectado pelo endereço")
            s.endsWith(".mpd") || s.contains(".mpd?") -> MediaDecision(MediaKind.DASH, "alta", "Manifesto DASH detectado pelo endereço")
            s.endsWith(".mp4") || s.endsWith(".webm") || s.endsWith(".3gp") -> MediaDecision(MediaKind.VIDEO_FILE, "alta", "Arquivo de vídeo detectado pelo endereço")
            s.startsWith("http://") || s.startsWith("https://") -> MediaDecision(MediaKind.WEB, "média", "Fonte web detectada; suporte depende do player")
            else -> MediaDecision(MediaKind.UNKNOWN, "baixa", "Não foi possível classificar a fonte")
        }
    }
}
