package br.com.fmdx.android.fm.database

import br.com.fmdx.android.fm.signature.HardwareSignature

data class KnownHardwareProfile(
    val signature: HardwareSignature,
    val notes: String,
    val recommendedMode: String
)

class ProfileDatabase {
    private val profiles = mutableListOf<KnownHardwareProfile>()
    fun add(profile: KnownHardwareProfile) { profiles.removeAll { it.signature.key == profile.signature.key }; profiles += profile }
    fun find(signature: HardwareSignature): KnownHardwareProfile? = profiles.firstOrNull { it.signature.key == signature.key }
    fun all(): List<KnownHardwareProfile> = profiles.toList()
}
