package br.com.fmdx.android.playback

import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class NativeAudioRequestValidatorTest {
    @Test fun acceptsDirectRadioAndAudioFormats() {
        assertTrue(NativeAudioRequestValidator.isSupported("radio", ""))
        assertTrue(NativeAudioRequestValidator.isSupported("audio/mpeg", "UNKNOWN"))
        assertTrue(NativeAudioRequestValidator.isSupported("", "MP3"))
        assertTrue(NativeAudioRequestValidator.isSupported("", "OPUS"))
    }

    @Test fun rejectsVideoAndPlaylistFormats() {
        assertFalse(NativeAudioRequestValidator.isSupported("tv", "HLS"))
        assertTrue(NativeAudioRequestValidator.isSupported("radio", "HLS"))
        assertTrue(NativeAudioRequestValidator.isSupported("audio", "MPEG-DASH"))
        assertFalse(NativeAudioRequestValidator.isSupported("radio", "M3U8"))
        assertFalse(NativeAudioRequestValidator.isSupported("video", "MP4"))
    }
}
