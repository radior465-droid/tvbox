package br.com.fmdx.android.fm.hybrid

import br.com.fmdx.android.fm.crystal.CrystalClockReport
import br.com.fmdx.android.fm.crystal.CrystalClockDiagnostics
import br.com.fmdx.android.fm.profile.HardwareProfile

enum class HybridMode { NATIVE_UNVALIDATED, ASSISTED_DIAGNOSTIC, VIRTUAL }

data class HybridRadioReport(
    val mode: HybridMode,
    val explanation: String,
    val crystal: CrystalClockReport
) {
    fun asText(): String = buildString {
        append("FM-DX — Hybrid Radio Engine 0.13.0\n\n")
        append("Modo: $mode\n")
        append("$explanation\n\n")
        append(crystal.asText())
    }
}

object HybridRadioEngine {
    fun evaluate(profile: HardwareProfile): HybridRadioReport {
        val hasPublicFeature = profile.evidence.any { it.type == "SYSTEM_FEATURE" }
        val mode = when {
            hasPublicFeature -> HybridMode.NATIVE_UNVALIDATED
            profile.confidenceScore >= 60 -> HybridMode.ASSISTED_DIAGNOSTIC
            else -> HybridMode.VIRTUAL
        }
        val explanation = when (mode) {
            HybridMode.NATIVE_UNVALIDATED -> "Há uma evidência pública relacionada a rádio. Isso justifica investigação de integração, mas não confirma uma API de sintonia funcional."
            HybridMode.ASSISTED_DIAGNOSTIC -> "A plataforma é reconhecida, porém sem controle público comprovado do tuner. O sistema trabalha com diagnóstico e perfil técnico."
            HybridMode.VIRTUAL -> "Não há evidência suficiente para selecionar um backend nativo. A camada virtual mantém a interface e o processamento independentes do tuner físico."
        }
        return HybridRadioReport(mode, explanation, CrystalClockDiagnostics.inspect(profile))
    }
}
