package br.com.fmdx.android.tv

import android.hardware.usb.UsbConstants
import android.hardware.usb.UsbDevice
import android.hardware.usb.UsbDeviceConnection
import android.hardware.usb.UsbEndpoint
import android.hardware.usb.UsbManager
import java.io.Closeable
import java.util.concurrent.atomic.AtomicBoolean

/**
 * Camada genérica de leitura USB bulk-IN para experimentação com receptores ISDB-T.
 * Não envia comandos de sintonia nem inicializa demoduladores: isso exige protocolo
 * específico do chipset/firmware. Só deve ser usada após identificar interface/endereço.
 */
class UsbBulkTsTransport(
    private val usbManager: UsbManager,
    private val device: UsbDevice,
    private val interfaceIndex: Int,
    private val endpointAddress: Int,
    private val onTransportChunk: (ByteArray) -> Unit,
    private val onStatus: (String) -> Unit = {}
) : Closeable {
    private val running = AtomicBoolean(false)
    private var connection: UsbDeviceConnection? = null
    private var claimedInterface: android.hardware.usb.UsbInterface? = null
    private var worker: Thread? = null

    @Synchronized
    fun start(): Boolean {
        if (running.get()) return true
        if (!usbManager.hasPermission(device)) {
            onStatus("Permissão USB não concedida")
            return false
        }
        if (interfaceIndex !in 0 until device.interfaceCount) {
            onStatus("Interface USB inexistente")
            return false
        }
        val intf = device.getInterface(interfaceIndex)
        val endpoint = (0 until intf.endpointCount)
            .map { intf.getEndpoint(it) }
            .firstOrNull { it.address == endpointAddress }
        if (endpoint == null || endpoint.direction != UsbConstants.USB_DIR_IN ||
            endpoint.type != UsbConstants.USB_ENDPOINT_XFER_BULK) {
            onStatus("Endpoint informado não é bulk-IN válido")
            return false
        }
        val conn = usbManager.openDevice(device) ?: run {
            onStatus("Não foi possível abrir o dispositivo USB")
            return false
        }
        if (!conn.claimInterface(intf, true)) {
            conn.close()
            onStatus("Não foi possível reservar a interface USB")
            return false
        }
        connection = conn
        claimedInterface = intf
        running.set(true)
        worker = Thread({ readLoop(conn, endpoint) }, "FM-DX-USB-TS").apply { isDaemon = true; start() }
        onStatus("Leitura USB bulk-IN iniciada; aguardando fluxo de transporte")
        return true
    }

    private fun readLoop(conn: UsbDeviceConnection, endpoint: UsbEndpoint) {
        val buffer = ByteArray(16 * 1024)
        while (running.get()) {
            val count = conn.bulkTransfer(endpoint, buffer, buffer.size, 1000)
            if (count > 0) {
                val bytes = buffer.copyOf(count)
                onTransportChunk(bytes)
            }
        }
    }

    @Synchronized
    override fun close() {
        running.set(false)
        worker?.interrupt()
        try { worker?.join(300) } catch (_: InterruptedException) { Thread.currentThread().interrupt() }
        val conn = connection
        val intf = claimedInterface
        if (conn != null && intf != null) {
            try { conn.releaseInterface(intf) } catch (_: Exception) { }
        }
        try { conn?.close() } catch (_: Exception) { }
        connection = null
        claimedInterface = null
        worker = null
        onStatus("Leitura USB encerrada")
    }
}

/** Alinha bytes recebidos em pacotes MPEG-TS de 188 bytes sem alterar o conteúdo. */
class MpegTsPacketAligner {
    private var pending = ByteArray(0)

    @Synchronized
    fun push(chunk: ByteArray): ByteArray {
        if (chunk.isEmpty()) return ByteArray(0)
        val data = pending + chunk
        var start = -1
        var i = 0
        while (i + MpegTsAnalyzer.PACKET_SIZE <= data.size) {
            if ((data[i].toInt() and 0xff) == 0x47 &&
                (i + MpegTsAnalyzer.PACKET_SIZE >= data.size ||
                    (data[i + MpegTsAnalyzer.PACKET_SIZE].toInt() and 0xff) == 0x47)) {
                start = i
                break
            }
            i++
        }
        if (start < 0) {
            pending = data.takeLast(minOf(data.size, MpegTsAnalyzer.PACKET_SIZE - 1)).toByteArray()
            return ByteArray(0)
        }
        val usable = ((data.size - start) / MpegTsAnalyzer.PACKET_SIZE) * MpegTsAnalyzer.PACKET_SIZE
        val output = data.copyOfRange(start, start + usable)
        pending = data.copyOfRange(start + usable, data.size)
        return output
    }
}
