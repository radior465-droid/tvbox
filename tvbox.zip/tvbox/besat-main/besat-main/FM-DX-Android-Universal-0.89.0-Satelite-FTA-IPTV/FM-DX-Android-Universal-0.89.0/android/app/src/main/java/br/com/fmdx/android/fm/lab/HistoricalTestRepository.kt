package br.com.fmdx.android.fm.lab

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/** Histórico local de execuções, agrupado por assinatura de hardware. */
class HistoricalTestRepository(context: Context) {
    private val prefs = context.getSharedPreferences("fmdx_historical_tests", Context.MODE_PRIVATE)

    data class Snapshot(
        val signature: String,
        val timestamp: Long,
        val version: String,
        val report: String
    )

    fun save(snapshot: Snapshot) {
        val array = JSONArray(prefs.getString("snapshots", "[]"))
        array.put(JSONObject().apply {
            put("signature", snapshot.signature)
            put("timestamp", snapshot.timestamp)
            put("version", snapshot.version)
            put("report", snapshot.report)
        })
        prefs.edit().putString("snapshots", array.toString()).apply()
    }

    fun history(signature: String): List<Snapshot> {
        val array = JSONArray(prefs.getString("snapshots", "[]"))
        return buildList {
            for (i in 0 until array.length()) {
                val o = array.getJSONObject(i)
                if (o.optString("signature") == signature) add(Snapshot(
                    signature = o.optString("signature"),
                    timestamp = o.optLong("timestamp"),
                    version = o.optString("version"),
                    report = o.optString("report")
                ))
            }
        }.sortedBy { it.timestamp }
    }

    fun clear() { prefs.edit().clear().apply() }
}
