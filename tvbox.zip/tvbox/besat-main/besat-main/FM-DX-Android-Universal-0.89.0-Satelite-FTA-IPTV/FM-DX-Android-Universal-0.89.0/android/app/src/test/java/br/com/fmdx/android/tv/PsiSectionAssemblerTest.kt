package br.com.fmdx.android.tv

import org.junit.Assert.*
import org.junit.Test

class PsiSectionAssemblerTest {
    private fun packet(pid: Int, cc: Int, pusi: Boolean, payload: ByteArray): ByteArray {
        val out = ByteArray(188) { 0xff.toByte() }
        out[0] = 0x47
        out[1] = (((if (pusi) 0x40 else 0) or ((pid shr 8) and 0x1f))).toByte()
        out[2] = pid.toByte()
        out[3] = (0x10 or (cc and 0x0f)).toByte()
        payload.copyInto(out, 4, 0, minOf(payload.size, 184))
        return out
    }

    @Test fun assemblesSectionSplitAcrossPackets() {
        val assembler = PsiSectionAssembler(0)
        // Minimal synthetic section: table id 0, section_length 9.
        val section = byteArrayOf(0x00, 0xB0.toByte(), 0x09, 0, 1, 0xC1.toByte(), 0, 0, 0, 0, 0, 0)
        val first = ByteArray(188) { 0xff.toByte() }
        first[0] = 0x47; first[1] = 0x40; first[2] = 0; first[3] = 0x30; first[4] = 176
        (byteArrayOf(0) + section.copyOfRange(0, 6)).copyInto(first, 181)
        assertTrue(assembler.feed(first).isEmpty())
        val second = assembler.feed(packet(0, 1, false, section.copyOfRange(6, section.size)))
        assertEquals(1, second.size)
        assertArrayEquals(section, second[0])
    }

    @Test fun ignoresOtherPidAndResetsOnContinuityGap() {
        val assembler = PsiSectionAssembler(0)
        val section = byteArrayOf(0x00, 0xB0.toByte(), 0x09, 0, 1, 0xC1.toByte(), 0, 0, 0, 0, 0, 0)
        assertTrue(assembler.feed(packet(1, 0, true, byteArrayOf(0) + section)).isEmpty())
        val partial = ByteArray(188) { 0xff.toByte() }
        partial[0] = 0x47; partial[1] = 0x40; partial[2] = 0; partial[3] = 0x30; partial[4] = 176.toByte()
        (byteArrayOf(0) + section.copyOfRange(0, 6)).copyInto(partial, 181)
        assertTrue(assembler.feed(partial).isEmpty())
        assertTrue(assembler.feed(packet(0, 3, false, section.copyOfRange(6, section.size))).isEmpty())
    }
}
