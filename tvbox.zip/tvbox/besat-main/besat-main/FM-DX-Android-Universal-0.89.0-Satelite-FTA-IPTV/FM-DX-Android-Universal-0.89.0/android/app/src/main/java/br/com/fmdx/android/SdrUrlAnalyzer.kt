package br.com.fmdx.android

import java.net.HttpURLConnection
import java.net.InetAddress
import java.net.URI
import java.net.URL

/** Analisa apenas uma URL pública informada pelo usuário; não rastreia sites nem segue redirecionamentos. */
object SdrUrlAnalyzer {
    data class Result(val url: String, val platform: String, val httpStatus: Int, val ranges: List<String>, val note: String) {
        fun asText(): String = buildString {
            append("Plataforma: ").append(platform)
            append("\nHTTP: ").append(httpStatus)
            append("\nFaixas anunciadas: ")
            append(if (ranges.isEmpty()) "não identificadas" else ranges.joinToString(", "))
            append("\n\n").append(note)
        }
    }

    fun scan(raw: String): Result {
        val uri = URI(raw.trim())
        require(uri.scheme.equals("http", true) || uri.scheme.equals("https", true)) { "Use uma URL HTTP ou HTTPS." }
        require(!uri.host.isNullOrBlank() && uri.userInfo == null) { "URL inválida." }
        require(uri.host.length <= 253) { "Endereço muito longo." }
        val addresses = InetAddress.getAllByName(uri.host)
        require(addresses.isNotEmpty() && addresses.all { it.isAnyLocalAddress.not() && it.isLoopbackAddress.not() && it.isLinkLocalAddress.not() && it.isSiteLocalAddress.not() && it.isMulticastAddress.not() }) {
            "Por segurança, o scanner aceita somente servidores com endereço IP público."
        }
        val connection = (URL(uri.toASCIIString()).openConnection() as HttpURLConnection).apply {
            connectTimeout = 7000
            readTimeout = 7000
            instanceFollowRedirects = false
            requestMethod = "GET"
            setRequestProperty("User-Agent", "FM-DX-Android-SDR-Explorer/0.88")
            setRequestProperty("Range", "bytes=0-262143")
        }
        try {
            val status = connection.responseCode
            val stream = if (status in 200..299) connection.inputStream else connection.errorStream
            val body = stream?.use { input ->
                val out = java.io.ByteArrayOutputStream()
                val buffer = ByteArray(8192)
                var total = 0
                while (total < 262144) {
                    val count = input.read(buffer, 0, minOf(buffer.size, 262144 - total))
                    if (count <= 0) break
                    out.write(buffer, 0, count); total += count
                }
                out.toString(Charsets.UTF_8.name())
            }.orEmpty()
            val text = (uri.host + " " + body).lowercase()
            val platform = when {
                "kiwisdr" in text || "kiwi" in uri.host.lowercase() -> "KiwiSDR"
                "openwebrx" in text || "openwebrx" in uri.host.lowercase() -> "OpenWebRX"
                "websdr" in text -> "WebSDR"
                "spyserver" in text || "sdrsharp" in text || "sdr#" in text -> "SpyServer / SDR#"
                "web-888" in text || "web888" in text -> "Web-888"
                else -> "SDR não identificado"
            }
            val ranges = linkedSetOf<String>()
            val regex = Regex("(?i)(\\d+(?:\\.\\d+)?)\\s*(MHz|kHz)\\s*(?:-|–|a|to)\\s*(\\d+(?:\\.\\d+)?)\\s*(MHz|kHz)")
            regex.findAll(body).take(20).forEach { match ->
                val a = match.groupValues[1].toDoubleOrNull() ?: return@forEach
                val b = match.groupValues[3].toDoubleOrNull() ?: return@forEach
                val scaleA = if (match.groupValues[2].equals("MHz", true)) 1.0 else 0.001
                val scaleB = if (match.groupValues[4].equals("MHz", true)) 1.0 else 0.001
                if (a > 0 && b > a && b * scaleB <= 3000) ranges += "${a * scaleA}–${b * scaleB} MHz"
            }
            val note = when {
                status in 300..399 -> "O servidor redirecionou a solicitação. Abra a URL final indicada pelo próprio diretório."
                ranges.isNotEmpty() -> "Faixas extraídas do texto público da página; confirme os limites na interface do receptor."
                else -> "A página respondeu, mas não publicou faixas reconhecíveis no trecho consultado."
            }
            return Result(uri.toASCIIString(), platform, status, ranges.toList(), note)
        } finally { connection.disconnect() }
    }
}
