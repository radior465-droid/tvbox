package br.com.fmdx.android.media.diagnostics

import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

data class DiagnosticEvent(
    val timestamp: Long = System.currentTimeMillis(),
    val category: String,
    val message: String
)

object DiagnosticLogExporter {
    fun toText(events: List<DiagnosticEvent>): String {
        val fmt = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US)
        return buildString {
            append("FM-DX Android Universal Diagnostic Log\n")
            events.forEach { event ->
                append(fmt.format(Date(event.timestamp)))
                append(" [").append(event.category).append("] ")
                append(event.message).append('\n')
            }
        }
    }
}
