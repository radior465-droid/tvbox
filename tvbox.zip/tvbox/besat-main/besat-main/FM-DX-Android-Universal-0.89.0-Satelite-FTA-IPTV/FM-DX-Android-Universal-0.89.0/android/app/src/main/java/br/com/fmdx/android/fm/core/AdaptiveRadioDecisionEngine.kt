package br.com.fmdx.android.fm.core

import br.com.fmdx.android.fm.crystal.CrystalClockDiagnostics
import br.com.fmdx.android.fm.profile.HardwareProfile

enum class AdaptiveMode { NATIVE_INVESTIGATION, ASSISTED, VIRTUAL }

data class AdaptiveRadioDecision(
    val mode: AdaptiveMode,
    val reason: String,
    val confidence: Int,
    val evidenceCount: Int,
    val nextStep: String
) {
    fun asText(profile: HardwareProfile): String = buildString {
        append("FM-DX — Adaptive Radio Decision Engine 0.15.0\n\n")
        append("Modo selecionado: $mode\n")
        append("Confiança do perfil: $confidence%\n")
        append("Evidências coletadas: $evidenceCount\n\n")
        append("DECISÃO\n$reason\n\n")
        append("PRÓXIMO PASSO\n$nextStep\n\n")
        append("SEGURANÇA TÉCNICA\nA decisão não concede acesso ao tuner, ao PLL ou ao cristal. Controle nativo só pode ser ativado após uma interface, API ou driver realmente validado.\n\n")
        append(CrystalClockDiagnostics.inspect(profile).asText())
    }

}

object AdaptiveRadioDecisionEngine {
    fun evaluate(profile: HardwareProfile): AdaptiveRadioDecision {
        val hasPublicFeature = profile.evidence.any { it.type == "SYSTEM_FEATURE" }
        val hasStrongEvidence = profile.evidence.any { it.confidence >= 80 }
        val mode = when {
            hasPublicFeature && hasStrongEvidence -> AdaptiveMode.NATIVE_INVESTIGATION
            profile.confidenceScore >= 50 -> AdaptiveMode.ASSISTED
            else -> AdaptiveMode.VIRTUAL
        }
        val reason = when (mode) {
            AdaptiveMode.NATIVE_INVESTIGATION -> "Foram encontradas evidências públicas suficientemente fortes para investigar uma integração nativa específica. Isso ainda não confirma sintonia ou áudio pelo tuner."
            AdaptiveMode.ASSISTED -> "O aparelho possui uma assinatura técnica reconhecível, mas falta uma interface pública comprovada para controle do receptor."
            AdaptiveMode.VIRTUAL -> "As evidências atuais não justificam selecionar um backend nativo. O rádio virtual oferece interface e análise independentes do tuner físico."
        }
        val next = when (mode) {
            AdaptiveMode.NATIVE_INVESTIGATION -> "Registrar o perfil, validar APIs/drivers expostos e testar operações somente de leitura antes de qualquer controle."
            AdaptiveMode.ASSISTED -> "Usar diagnóstico, assinatura de hardware e DSP com fontes de áudio autorizadas; aguardar evidência de integração nativa."
            AdaptiveMode.VIRTUAL -> "Usar perfis de estação e DSP com fontes autorizadas, mantendo o perfil do aparelho para futuras atualizações."
        }
        return AdaptiveRadioDecision(mode, reason, profile.confidenceScore, profile.evidence.size, next)
    }
}
