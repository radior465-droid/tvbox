package br.com.fmdx.android.tv

import org.junit.Assert.*
import org.junit.Test

class TvCompatibilityTest {
    @Test fun brazilPrefersIsdbt() { assertEquals(TvStandard.ISDB_T, TvCompatibility.profile("BR").preferredStandard) }
    @Test fun videoClassIsOnlyEvidence() {
        val result = TvCompatibility.classify(listOf(0x0e))
        assertTrue(result.first)
        assertTrue(result.second.contains("confirmar"))
    }
    @Test fun vendorSpecificClassIsOnlyAHeuristic() {
        val result = TvCompatibility.classify(listOf(0xff))
        assertTrue(result.first)
        assertTrue(result.second.contains("VID/PID"))
    }
    @Test fun emptyInterfacesAreNotClaimedAsTuner() { assertFalse(TvCompatibility.classify(emptyList()).first) }
    @Test fun unrelatedUsbClassIsNotClaimedAsTuner() { assertFalse(TvCompatibility.classify(listOf(0x08)).first) }
}
