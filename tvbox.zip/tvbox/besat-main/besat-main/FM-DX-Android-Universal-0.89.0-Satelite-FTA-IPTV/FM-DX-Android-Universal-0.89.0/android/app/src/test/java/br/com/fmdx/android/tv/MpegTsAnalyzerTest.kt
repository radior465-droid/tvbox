package br.com.fmdx.android.tv

import org.junit.Assert.*
import org.junit.Test

class MpegTsAnalyzerTest {
    private fun packet(pid: Int, tei: Boolean = false, scrambling: Int = 0): ByteArray {
        val b = ByteArray(188)
        b[0] = 0x47.toByte()
        b[1] = (((pid shr 8) and 0x1f) or if (tei) 0x80 else 0).toByte()
        b[2] = (pid and 0xff).toByte()
        b[3] = ((scrambling shl 6) or 0x10 or 3).toByte()
        return b
    }
    @Test fun parsesPidAndCounter() {
        val p = MpegTsAnalyzer.parsePacket(packet(0x123, tei = true))!!
        assertEquals(0x123, p.pid); assertTrue(p.transportError); assertEquals(3, p.continuityCounter)
    }
    @Test fun rejectsBadSyncAndReservedControl() {
        val badSync = packet(10).also { it[0] = 0 }
        val badControl = packet(10).also { it[3] = 0 }
        assertNull(MpegTsAnalyzer.parsePacket(badSync)); assertNull(MpegTsAnalyzer.parsePacket(badControl))
    }
    @Test fun countsPacketsAndUniquePids() {
        val data = packet(100) + packet(100, tei = true) + packet(0x1fff, scrambling = 2)
        val stats = MpegTsAnalyzer.analyze(data)
        assertEquals(3, stats.packets); assertEquals(0, stats.syncErrors)
        assertEquals(1, stats.transportErrors); assertEquals(1, stats.scrambledPackets)
        assertEquals(1, stats.nullPackets); assertEquals(2, stats.distinctPids)
    }
}
