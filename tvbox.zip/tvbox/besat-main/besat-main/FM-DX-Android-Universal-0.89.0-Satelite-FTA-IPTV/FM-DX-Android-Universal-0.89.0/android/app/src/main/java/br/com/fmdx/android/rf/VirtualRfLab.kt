package br.com.fmdx.android.rf

import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.ln
import kotlin.math.sin
import kotlin.math.sqrt

/**
 * Laboratório de sinais sintéticos. Não acessa hardware nem representa medições RF reais.
 */
object VirtualRfLab {
    data class Peak(val bin: Int, val frequencyHz: Double, val levelDb: Double)
    data class Spectrum(val sampleRateHz: Double, val samples: Int, val levelsDb: List<Double>, val peaks: List<Peak>)

    fun generate(
        sampleCount: Int = 2048,
        sampleRateHz: Double = 2_400_000.0,
        tonesHz: List<Double> = listOf(-420_000.0, 135_000.0, 510_000.0),
        noiseAmplitude: Double = 0.035,
        seed: Long = 47L
    ): Pair<DoubleArray, DoubleArray> {
        require(sampleCount >= 256 && sampleCount and (sampleCount - 1) == 0) { "Amostras devem ser potência de 2 (mínimo 256)." }
        require(sampleRateHz > 0.0 && noiseAmplitude >= 0.0)
        require(tonesHz.all { it in -sampleRateHz / 2.0..sampleRateHz / 2.0 })
        var state = seed
        fun randomUnit(): Double {
            state = state * 6364136223846793005L + 1442695040888963407L
            return ((state ushr 11).toDouble() / (1L shl 53).toDouble()) * 2.0 - 1.0
        }
        val i = DoubleArray(sampleCount)
        val q = DoubleArray(sampleCount)
        for (n in 0 until sampleCount) {
            var re = noiseAmplitude * randomUnit()
            var im = noiseAmplitude * randomUnit()
            for ((index, f) in tonesHz.withIndex()) {
                val phase = 2.0 * PI * f * n / sampleRateHz + index * 0.37
                val amplitude = when (index) { 0 -> 0.72; 1 -> 0.48; else -> 0.30 }
                re += amplitude * cos(phase)
                im += amplitude * sin(phase)
            }
            i[n] = re
            q[n] = im
        }
        return i to q
    }

    fun analyze(i: DoubleArray, q: DoubleArray, sampleRateHz: Double, centerFrequencyHz: Double = 0.0): Spectrum {
        require(i.size == q.size && i.size >= 256 && i.size and (i.size - 1) == 0)
        require(sampleRateHz > 0.0)
        val n = i.size
        val re = DoubleArray(n)
        val im = DoubleArray(n)
        for (k in 0 until n) {
            val window = 0.5 - 0.5 * cos(2.0 * PI * k / (n - 1))
            re[k] = i[k] * window
            im[k] = q[k] * window
        }
        fft(re, im)
        val levels = DoubleArray(n)
        for (k in 0 until n) {
            val shifted = (k + n / 2) % n
            val magnitude = sqrt(re[shifted] * re[shifted] + im[shifted] * im[shifted]) / n
            levels[k] = 20.0 * ln(magnitude.coerceAtLeast(1e-12)) / ln(10.0)
        }
        val peaks = (1 until levels.lastIndex)
            .filter { levels[it] > levels[it - 1] && levels[it] >= levels[it + 1] }
            .sortedByDescending { levels[it] }
            .take(8)
            .map { bin ->
                val offset = (bin.toDouble() / levels.size - 0.5) * sampleRateHz
                Peak(bin, centerFrequencyHz + offset, levels[bin])
            }
        return Spectrum(sampleRateHz, n, levels.toList(), peaks)
    }

    private fun fft(re: DoubleArray, im: DoubleArray) {
        val n = re.size
        var j = 0
        for (i in 1 until n) {
            var bit = n shr 1
            while (j and bit != 0) { j = j xor bit; bit = bit shr 1 }
            j = j xor bit
            if (i < j) {
                val tr = re[i]; re[i] = re[j]; re[j] = tr
                val ti = im[i]; im[i] = im[j]; im[j] = ti
            }
        }
        var length = 2
        while (length <= n) {
            val angle = -2.0 * PI / length
            val wLenRe = cos(angle)
            val wLenIm = sin(angle)
            var start = 0
            while (start < n) {
                var wRe = 1.0
                var wIm = 0.0
                for (k in 0 until length / 2) {
                    val even = start + k
                    val odd = even + length / 2
                    val vRe = re[odd] * wRe - im[odd] * wIm
                    val vIm = re[odd] * wIm + im[odd] * wRe
                    re[odd] = re[even] - vRe
                    im[odd] = im[even] - vIm
                    re[even] += vRe
                    im[even] += vIm
                    val nextRe = wRe * wLenRe - wIm * wLenIm
                    wIm = wRe * wLenIm + wIm * wLenRe
                    wRe = nextRe
                }
                start += length
            }
            length = length shl 1
        }
    }
}
