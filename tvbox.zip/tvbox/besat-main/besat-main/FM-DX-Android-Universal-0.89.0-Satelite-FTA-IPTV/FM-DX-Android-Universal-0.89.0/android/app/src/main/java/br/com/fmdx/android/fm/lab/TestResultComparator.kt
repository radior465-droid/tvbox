package br.com.fmdx.android.fm.lab

/** Comparação conservadora de relatórios: detecta mudanças textuais sem inferir acesso ao hardware. */
object TestResultComparator {
    fun compare(previous: String?, current: String): String {
        if (previous.isNullOrBlank()) return "Primeira execução registrada para esta assinatura."
        if (previous == current) return "Nenhuma mudança observável em relação à execução anterior."
        return "Mudanças observadas entre execuções. Compare as evidências e detalhes; a diferença não prova novo acesso ao tuner ou ao cristal."
    }
}
