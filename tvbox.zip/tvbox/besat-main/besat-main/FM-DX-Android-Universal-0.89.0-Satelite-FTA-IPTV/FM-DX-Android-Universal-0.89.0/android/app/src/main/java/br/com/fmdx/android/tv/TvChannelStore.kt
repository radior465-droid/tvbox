package br.com.fmdx.android.tv

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

data class TvChannel(val url: String, val name: String, val category: String = "Geral", val favorite: Boolean = false)

class TvChannelStore(context: Context) {
    private val prefs = context.getSharedPreferences("fmdx_tv_channels", Context.MODE_PRIVATE)

    fun load(): List<TvChannel> = try {
        val a = JSONArray(prefs.getString("channels", "[]"))
        (0 until a.length()).mapNotNull { i ->
            a.optJSONObject(i)?.let { o ->
                TvChannel(o.optString("url"), o.optString("name", "Canal"), o.optString("category", "Geral"), o.optBoolean("favorite", false))
            }
        }.filter { it.url.isNotBlank() }
    } catch (_: Exception) { emptyList() }

    fun save(channel: TvChannel) {
        val all = load().filterNot { it.url == channel.url }.toMutableList()
        all.add(channel)
        persist(all)
    }

    fun toggleFavorite(url: String) {
        persist(load().map { if (it.url == url) it.copy(favorite = !it.favorite) else it })
    }

    fun remove(url: String) = persist(load().filterNot { it.url == url })

    private fun persist(items: List<TvChannel>) {
        val a = JSONArray()
        items.forEach { c -> a.put(JSONObject().put("url", c.url).put("name", c.name).put("category", c.category).put("favorite", c.favorite)) }
        prefs.edit().putString("channels", a.toString()).apply()
    }
}

class TvHistoryStore(context: Context) {
    private val prefs = context.getSharedPreferences("fmdx_tv_history", Context.MODE_PRIVATE)
    fun load(): List<TvChannel> = try {
        val a = JSONArray(prefs.getString("history", "[]"))
        (0 until a.length()).mapNotNull { i ->
            a.optJSONObject(i)?.let { o -> TvChannel(o.optString("url"), o.optString("name", "Canal"), o.optString("category", "Geral")) }
        }.filter { it.url.isNotBlank() }
    } catch (_: Exception) { emptyList() }

    fun add(channel: TvChannel) {
        val all = load().filterNot { it.url == channel.url }.toMutableList()
        all.add(0, channel)
        val a = JSONArray()
        all.take(20).forEach { c -> a.put(JSONObject().put("url",c.url).put("name",c.name).put("category",c.category)) }
        prefs.edit().putString("history", a.toString()).apply()
    }

    fun clear() = prefs.edit().remove("history").apply()
}
