package br.com.fmdx.android.tv

/** PAT/PMT section decoder for already-demultiplexed MPEG-TS PSI sections.
 * It does not tune RF, reassemble sections across packets, or decode A/V.
 */
data class TvProgramEntry(val programNumber: Int, val pmtPid: Int)
data class TvElementaryStream(val streamType: Int, val elementaryPid: Int)
data class TvPmtInfo(val programNumber: Int, val pcrPid: Int, val streams: List<TvElementaryStream>)

object TvProgramTableParser {
    /** Parses a complete PAT section (table_id 0x00), excluding TS packet headers. */
    fun parsePat(section: ByteArray): List<TvProgramEntry> {
        if (section.size < 12 || (section[0].toInt() and 0xff) != 0x00) return emptyList()
        val sectionLength = ((section[1].toInt() and 0x0f) shl 8) or (section[2].toInt() and 0xff)
        val end = 3 + sectionLength
        if (sectionLength < 9 || end > section.size) return emptyList()
        val entriesEnd = end - 4 // CRC_32
        val result = mutableListOf<TvProgramEntry>()
        var i = 8
        while (i + 4 <= entriesEnd) {
            val program = ((section[i].toInt() and 0xff) shl 8) or (section[i + 1].toInt() and 0xff)
            val pid = ((section[i + 2].toInt() and 0x1f) shl 8) or (section[i + 3].toInt() and 0xff)
            if (program != 0) result += TvProgramEntry(program, pid)
            i += 4
        }
        return if (i == entriesEnd) result else emptyList()
    }

    /** Parses a complete PMT section (table_id 0x02), excluding TS packet headers. */
    fun parsePmt(section: ByteArray): TvPmtInfo? {
        if (section.size < 16 || (section[0].toInt() and 0xff) != 0x02) return null
        val sectionLength = ((section[1].toInt() and 0x0f) shl 8) or (section[2].toInt() and 0xff)
        val end = 3 + sectionLength
        if (sectionLength < 13 || end > section.size) return null
        val program = ((section[3].toInt() and 0xff) shl 8) or (section[4].toInt() and 0xff)
        val pcrPid = ((section[8].toInt() and 0x1f) shl 8) or (section[9].toInt() and 0xff)
        val programInfoLength = ((section[10].toInt() and 0x0f) shl 8) or (section[11].toInt() and 0xff)
        var i = 12 + programInfoLength
        val streamsEnd = end - 4
        if (i > streamsEnd) return null
        val streams = mutableListOf<TvElementaryStream>()
        while (i + 5 <= streamsEnd) {
            val type = section[i].toInt() and 0xff
            val pid = ((section[i + 1].toInt() and 0x1f) shl 8) or (section[i + 2].toInt() and 0xff)
            val infoLength = ((section[i + 3].toInt() and 0x0f) shl 8) or (section[i + 4].toInt() and 0xff)
            i += 5 + infoLength
            if (i > streamsEnd) return null
            streams += TvElementaryStream(type, pid)
        }
        if (i != streamsEnd) return null
        return TvPmtInfo(program, pcrPid, streams)
    }
}
