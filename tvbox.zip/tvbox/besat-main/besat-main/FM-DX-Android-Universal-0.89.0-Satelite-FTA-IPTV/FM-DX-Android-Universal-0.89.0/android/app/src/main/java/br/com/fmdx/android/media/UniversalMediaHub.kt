package br.com.fmdx.android.media

enum class HubSection { RADIO, TV_VIDEO, FAVORITES, HISTORY, DEVICES, DIAGNOSTICS }

data class HubItem(
    val title: String,
    val section: HubSection,
    val subtitle: String,
    val available: Boolean = true
)

/**
 * 0.28.0 central navigation model. It only describes available app modules;
 * it does not claim hardware support that has not been verified.
 */
object UniversalMediaHub {
    fun items(): List<HubItem> = listOf(
        HubItem("Rádio FM", HubSection.RADIO, "Receptor, diagnóstico e recursos virtuais"),
        HubItem("TV e Vídeo", HubSection.TV_VIDEO, "Canais, streams e player"),
        HubItem("Favoritos", HubSection.FAVORITES, "Fontes marcadas pelo usuário"),
        HubItem("Histórico", HubSection.HISTORY, "Itens reproduzidos e acessados"),
        HubItem("Dispositivos", HubSection.DEVICES, "USB detectado e status de compatibilidade"),
        HubItem("Diagnóstico", HubSection.DIAGNOSTICS, "Evidências, testes e relatórios")
    )
}
