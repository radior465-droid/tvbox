package br.com.fmdx.android.fm.core

import br.com.fmdx.android.fm.profile.HardwareProfile

data class CompatibilityDecision(val mode: String, val explanation: String)

object DecisionEngine {
    fun decide(profile: HardwareProfile): CompatibilityDecision = when {
        profile.evidence.any { it.type == "SYSTEM_FEATURE" } -> CompatibilityDecision(
            "ADAPTER_MODE", "Recurso público relacionado foi observado; acesso específico ainda precisa ser validado.")
        profile.confidenceScore >= 60 -> CompatibilityDecision(
            "DIAGNOSTIC_MODE", "Plataforma reconhecida, porém controle público do tuner não foi confirmado.")
        else -> CompatibilityDecision(
            "DIAGNOSTIC_MODE", "Evidências insuficientes para selecionar um backend de controle.")
    }
}
