package br.com.fmdx.android.fm
class MediaTekFmController : PlatformFmController("MediaTek — diagnóstico")
