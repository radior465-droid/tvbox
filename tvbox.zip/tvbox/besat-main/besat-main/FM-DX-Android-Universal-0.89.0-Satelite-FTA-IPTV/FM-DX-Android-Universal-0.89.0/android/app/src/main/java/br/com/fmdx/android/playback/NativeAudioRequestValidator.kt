package br.com.fmdx.android.playback

/** Elegibilidade do player nativo Media3: áudio direto e HLS/DASH de rádio. */
object NativeAudioRequestValidator {
    private val unsupportedFormats = setOf("MPEG-TS", "M3U", "M3U8")
    private val directAudioFormats = setOf("MP3", "AAC", "OGG", "OPUS", "WAV", "FLAC")
    private val adaptiveFormats = setOf("HLS", "MPEG-DASH", "DASH")

    fun isSupported(media: String?, format: String?): Boolean {
        val type = media.orEmpty().trim().lowercase()
        val codec = format.orEmpty().trim().uppercase()
        if (codec in unsupportedFormats || type == "tv" || type == "video") return false
        if (codec in adaptiveFormats) return type == "radio" || type.startsWith("audio/")
        return type == "radio" || type.startsWith("audio/") || codec in directAudioFormats
    }
}
