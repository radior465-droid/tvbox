package br.com.fmdx.android.fm.signature

import br.com.fmdx.android.fm.profile.HardwareProfile

data class HardwareSignature(
    val key: String,
    val platform: String,
    val evidenceTypes: Set<String>
)

object SignatureGenerator {
    fun generate(profile: HardwareProfile): HardwareSignature {
        val types = profile.evidence.map { it.type }.toSortedSet()
        val key = listOf(profile.manufacturer.lowercase(), profile.model.lowercase(), profile.platform.lowercase(), types.joinToString(","))
            .joinToString("|")
        return HardwareSignature(key, profile.platform, types)
    }
}
