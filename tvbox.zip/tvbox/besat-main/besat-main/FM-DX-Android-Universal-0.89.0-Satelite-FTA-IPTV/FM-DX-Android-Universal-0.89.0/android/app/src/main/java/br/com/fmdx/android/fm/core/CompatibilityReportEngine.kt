package br.com.fmdx.android.fm.core

import android.os.Build
import br.com.fmdx.android.fm.database.CompatibilityRecord
import br.com.fmdx.android.fm.profile.HardwareProfile
import br.com.fmdx.android.fm.signature.SignatureGenerator
import java.text.DateFormat
import java.util.Date

/** Produces a human-readable evidence report. Historical data remains diagnostic only. */
object CompatibilityReportEngine {
    fun current(profile: HardwareProfile): Pair<String, CompatibilityRecord> {
        val signature = SignatureGenerator.generate(profile)
        val decision = AdaptiveRadioDecisionEngine.evaluate(profile)
        val confidence = profile.confidenceScore.coerceIn(0, 100)
        val evidence = if (profile.evidence.isEmpty()) "Nenhuma evidência pública coletada" else
            profile.evidence.joinToString("; ") { "${it.type}=${it.value} [${it.status}]" }
        val record = CompatibilityRecord(
            fingerprint = signature.key,
            manufacturer = Build.MANUFACTURER.ifBlank { "Desconhecido" },
            model = Build.MODEL.ifBlank { "Desconhecido" },
            platform = profile.platform,
            recommendedMode = decision.mode.name,
            evidenceSummary = evidence,
            lastTestResult = "Diagnóstico atualizado",
            confidence = confidence
        )
        val text = buildString {
            append("RELATÓRIO COMPLETO DO DISPOSITIVO\n\n")
            append("Fabricante: ${record.manufacturer}\n")
            append("Modelo: ${record.model}\n")
            append("Plataforma: ${record.platform}\n")
            append("Assinatura: ${record.fingerprint}\n\n")
            append("RECOMENDAÇÃO\n")
            append("Modo: ${record.recommendedMode}\n")
            append("Confiança diagnóstica: ${record.confidence}%\n")
            append("Motivo: ${decision.explanation}\n\n")
            append("EVIDÊNCIAS\n")
            if (profile.evidence.isEmpty()) append("• Nenhuma evidência coletada.\n")
            else profile.evidence.forEach { append("• ${it.type}: ${it.value} [${it.status}, ${it.confidence}%]\n") }
            append("\nLIMITES\n")
            append("Este relatório registra observações e recomendações. Ele não prova controle do tuner FM, do PLL ou do cristal físico.\n")
        }
        return text to record
    }

    fun history(records: List<CompatibilityRecord>): String = buildString {
        append("HISTÓRICO LOCAL DE COMPATIBILIDADE\n\n")
        if (records.isEmpty()) append("Nenhum teste salvo neste aparelho.\n")
        else records.sortedByDescending { it.updatedAt }.forEachIndexed { index, r ->
            append("${index + 1}. ${r.manufacturer} ${r.model}\n")
            append("   Plataforma: ${r.platform}\n")
            append("   Modo: ${r.recommendedMode}\n")
            append("   Resultado: ${r.lastTestResult}\n")
            append("   Confiança: ${r.confidence}%\n")
            append("   Atualizado: ${DateFormat.getDateTimeInstance().format(Date(r.updatedAt))}\n\n")
        }
        append("Histórico é evidência local e não substitui uma API, driver ou interface validada.\n")
    }
}
