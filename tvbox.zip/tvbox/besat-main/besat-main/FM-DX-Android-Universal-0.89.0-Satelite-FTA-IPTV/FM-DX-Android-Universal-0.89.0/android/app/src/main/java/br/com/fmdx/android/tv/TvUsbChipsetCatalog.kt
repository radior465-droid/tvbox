package br.com.fmdx.android.tv

/** Catálogo conservador de identificadores USB publicamente conhecidos.
 * Uma correspondência identifica uma família provável, nunca comprova revisão de placa,
 * demodulador, firmware ou compatibilidade Android.
 */
data class TvUsbChipsetProfile(
    val vendorId: Int,
    val productId: Int,
    val chipset: String,
    val tunerFamily: String,
    val standards: List<TvStandard>,
    val confidence: String,
    val driverStatus: String,
    val notes: String
) {
    fun matches(vid: Int, pid: Int): Boolean = vendorId == vid && productId == pid
}

object TvUsbChipsetCatalog {
    private val profiles = listOf(
        TvUsbChipsetProfile(
            vendorId = 0x0bda, productId = 0x2838,
            chipset = "Realtek RTL2832U (família provável)",
            tunerFamily = "DVB-T USB",
            standards = listOf(TvStandard.DVB_T),
            confidence = "VID/PID conhecido; revisão interna não confirmada",
            driverStatus = "Sem driver Android universal integrado",
            notes = "O RTL2832U é um demodulador DVB-T frequentemente usado em dongles SDR/DVB. O tuner RF e a placa variam entre fabricantes. Não presumir ISDB-T/SBTVD."
        ),
        TvUsbChipsetProfile(
            vendorId = 0x048d, productId = 0x275a,
            chipset = "ITE/Afatech IT9175 (família PT275; identificação reportada)",
            tunerFamily = "ISDB-T USB",
            standards = listOf(TvStandard.ISDB_T),
            confidence = "VID/PID e família associados por projeto Android ISDB-T de código aberto",
            driverStatus = "Driver/protocolo específico documentado em OpenDTV; integração FM-DX ainda não implementada",
            notes = "OpenDTV lista Mygica PadTV PT275, GMA Now e IT9175 com USB 048d:275a como suportados em hardware. Exige USB Host/OTG e dongle compatível; não assumir que toda placa com este ID seja idêntica."
        ),
        TvUsbChipsetProfile(
            vendorId = 0x048d, productId = 0x9308,
            chipset = "ITE IT9308 (identificação reportada)",
            tunerFamily = "ISDB-T USB",
            standards = listOf(TvStandard.ISDB_T),
            confidence = "VID/PID documentado; suporte de hardware reportado com ressalva de testes",
            driverStatus = "Caminho de driver separado no OpenDTV; integração FM-DX não implementada",
            notes = "OpenDTV associa 048d:9308 ao ABS-CBN TV Plus GO/Tolka IT9308 e informa que precisa de mais testes."
        ),
        TvUsbChipsetProfile(
            vendorId = 0x3275, productId = 0x0080,
            chipset = "Siano RIO (família reportada)",
            tunerFamily = "ISDB-T USB",
            standards = listOf(TvStandard.ISDB_T),
            confidence = "ID USB listado por projeto userspace independente; confirmar revisão e firmware",
            driverStatus = "Projeto siano-userland; não é driver APK integrado ao FM-DX",
            notes = "O projeto Khronos31/siano-userland lista 3275:0080 como dispositivo Siano RIO ISDB-T e exige firmware isdbt_rio.inp. Android citado é via Termux, não integração nativa do FM-DX."
        ),
        TvUsbChipsetProfile(
            vendorId = 0x187f, productId = 0x0600,
            chipset = "Siano RIO (família reportada)",
            tunerFamily = "ISDB-T USB",
            standards = listOf(TvStandard.ISDB_T),
            confidence = "ID USB listado por projeto userspace independente; confirmar revisão e firmware",
            driverStatus = "Projeto siano-userland; não é driver APK integrado ao FM-DX",
            notes = "O projeto Khronos31/siano-userland lista 187f:0600 como dispositivo Siano RIO ISDB-T. Requer firmware apropriado e validação no aparelho."
        ),
        TvUsbChipsetProfile(
            vendorId = 0x187f, productId = 0x0302,
            chipset = "Siano RIO (família reportada)",
            tunerFamily = "ISDB-T USB",
            standards = listOf(TvStandard.ISDB_T),
            confidence = "ID USB listado por projeto userspace independente; confirmar revisão e firmware",
            driverStatus = "Projeto siano-userland; não é driver APK integrado ao FM-DX",
            notes = "O projeto Khronos31/siano-userland lista 187f:0302 como dispositivo Siano RIO ISDB-T. Requer firmware apropriado e validação no aparelho."
        ),
        TvUsbChipsetProfile(
            vendorId = 0x0bda, productId = 0x2832,
            chipset = "Realtek RTL2832 (família provável)",
            tunerFamily = "DVB-T USB / possível variante SDR",
            standards = listOf(TvStandard.DVB_T),
            confidence = "VID/PID conhecido; confirmar descritores e placa",
            driverStatus = "Sem driver Android universal integrado",
            notes = "A identificação USB não revela o tuner RF conectado nem garante recepção de TV."
        )
    )

    fun identify(vendorId: Int, productId: Int): TvUsbChipsetProfile? =
        profiles.firstOrNull { it.matches(vendorId, productId) }

    fun all(): List<TvUsbChipsetProfile> = profiles.toList()

    fun describe(vendorId: Int, productId: Int): String {
        val profile = identify(vendorId, productId) ?: return "Chipset não catalogado. Guardar VID/PID e descritores para pesquisa; não inferir padrão ou driver."
        return buildString {
            append(profile.chipset)
            append("\nFamília: ").append(profile.tunerFamily)
            append("\nPadrões associados: ").append(profile.standards.joinToString { it.displayName })
            append("\nConfiança: ").append(profile.confidence)
            append("\nDriver: ").append(profile.driverStatus)
            append("\n").append(profile.notes)
        }
    }
}
