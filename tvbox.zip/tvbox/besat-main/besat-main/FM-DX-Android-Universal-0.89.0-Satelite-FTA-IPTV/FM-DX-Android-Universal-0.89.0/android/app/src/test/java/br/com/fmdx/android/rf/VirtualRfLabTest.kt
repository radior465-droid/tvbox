package br.com.fmdx.android.rf

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class VirtualRfLabTest {
    @Test fun generatorIsDeterministicForSameSeed() {
        val first = VirtualRfLab.generate(seed = 1234L)
        val second = VirtualRfLab.generate(seed = 1234L)
        assertTrue(first.first.contentEquals(second.first))
        assertTrue(first.second.contentEquals(second.second))
    }

    @Test fun fftFindsExpectedSyntheticCarriers() {
        val rate = 2_400_000.0
        val center = 100_000_000.0
        val (i, q) = VirtualRfLab.generate(sampleCount = 4096, sampleRateHz = rate, seed = 47L)
        val result = VirtualRfLab.analyze(i, q, rate, center)
        assertEquals(4096, result.levelsDb.size)
        assertTrue(result.peaks.isNotEmpty())
        assertTrue(result.peaks.all { it.frequencyHz in center - rate / 2..center + rate / 2 })
    }

    @Test(expected = IllegalArgumentException::class)
    fun rejectsNonPowerOfTwoSampleCount() {
        VirtualRfLab.generate(sampleCount = 1000)
    }

    @Test(expected = IllegalArgumentException::class)
    fun rejectsMismatchedIqArrays() {
        VirtualRfLab.analyze(DoubleArray(256), DoubleArray(512), 1_000_000.0)
    }
}
