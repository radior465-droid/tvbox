package br.com.fmdx.android.video

object VideoSourceDetector {
    fun detect(url: String): VideoSource.Type {
        val value = url.substringBefore('?').lowercase()
        return when {
            value.endsWith(".m3u8") -> VideoSource.Type.HLS
            value.endsWith(".mpd") -> VideoSource.Type.DASH
            value.endsWith(".mp4") || value.endsWith(".webm") || value.endsWith(".3gp") -> VideoSource.Type.MP4
            else -> VideoSource.Type.AUTO
        }
    }
}
