const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const root = path.join(__dirname, '../../android/app/src/main/java/br/com/fmdx/android/tv');

test('descoberta de serviços valida CRC MPEG-2 antes de aceitar PAT/PMT', () => {
  const crc = fs.readFileSync(path.join(root, 'MpegPsiCrc32.kt'), 'utf8');
  const discovery = fs.readFileSync(path.join(root, 'TvServiceDiscovery.kt'), 'utf8');
  assert.match(crc, /0x04C11DB7L/);
  assert.match(crc, /calculate\(section\) == 0L/);
  assert.match(discovery, /MpegPsiCrc32\.isValidSection\(section\)/);
});

test('catálogo liga PAT a PMT e separa PIDs de áudio e vídeo', () => {
  const discovery = fs.readFileSync(path.join(root, 'TvServiceDiscovery.kt'), 'utf8');
  assert.match(discovery, /PsiSectionAssembler\(0x0000\)/);
  assert.match(discovery, /programToPmtPid\[pmt\.programNumber\] != pid/);
  assert.match(discovery, /videoPids/);
  assert.match(discovery, /audioPids/);
});

test('documentação deixa explícito que descoberta não sintoniza RF', () => {
  const changelog = fs.readFileSync(path.join(__dirname, '../../CHANGELOG-0.78.0.md'), 'utf8');
  assert.match(changelog, /Não implementa firmware.*sintonia RF/s);
  assert.match(changelog, /não executados neste ambiente/);
});
