'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const root = path.join(__dirname, '../../android/app/src');

test('0.83.0 fornece linha do tempo textual com duração e consulta temporal', () => {
  const source = fs.readFileSync(path.join(root, 'main/java/br/com/fmdx/android/tv/IsdbtCaptionTimeline.kt'), 'utf8');
  assert.match(source, /data class IsdbtCaptionCue/);
  assert.match(source, /fun addTextBlock/);
  assert.match(source, /fun activeAt/);
  assert.match(source, /AribB24Decoder/);
});

test('linha do tempo limita memória e rejeita entradas inválidas', () => {
  const source = fs.readFileSync(path.join(root, 'main/java/br/com/fmdx/android/tv/IsdbtCaptionTimeline.kt'), 'utf8');
  assert.match(source, /MAX_TEXT_BYTES/);
  assert.match(source, /MAX_CUE_DURATION_MS/);
  assert.match(source, /while \(cues\.size > maxCues\)/);
  assert.match(source, /cueId in seenIds/);
});

test('documentação não afirma demultiplexação ou legendas ao vivo concluídas', () => {
  const doc = fs.readFileSync(path.join(__dirname, '../../CHANGELOG-0.83.0.md'), 'utf8');
  assert.match(doc, /já extraído/);
  assert.match(doc, /Ainda não/);
});
