'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const root = path.join(__dirname, '../../android/app/src/main');

test('0.82.0 adiciona grade EPG com agrupamento, ordenação e fuso local', () => {
  const model = fs.readFileSync(path.join(root, 'java/br/com/fmdx/android/tv/IsdbtEpgGrid.kt'), 'utf8');
  assert.match(model, /groupBy \{ it\.serviceId \}/);
  assert.match(model, /ZoneId\.systemDefault\(\)/);
  assert.match(model, /sortedWith\(compareBy/);
  assert.match(model, /Programa sem título/);
});

test('tela EPG não inventa programação quando não há dados SI reais', () => {
  const activity = fs.readFileSync(path.join(root, 'java/br/com/fmdx/android/MainActivity.kt'), 'utf8');
  assert.match(activity, /Guia de Programação EPG/);
  assert.match(activity, /AGUARDANDO DADOS DE PROGRAMAÇÃO/);
  assert.match(activity, /Nenhum programa fictício será exibido/);
});
