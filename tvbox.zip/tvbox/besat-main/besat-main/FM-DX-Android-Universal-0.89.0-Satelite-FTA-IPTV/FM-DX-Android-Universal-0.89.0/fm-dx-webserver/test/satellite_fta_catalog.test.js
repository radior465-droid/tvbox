const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');

const page = fs.readFileSync(path.join(__dirname, '../web/internet-media.ejs'), 'utf8');

test('interface oferece cadastro local de canais FTA para TV e rádio', () => {
  assert.match(page, /id="ftaChannelsPanel"/);
  assert.match(page, /id="ftaChannelType"/);
  assert.match(page, /<option>TV<\/option><option>Rádio<\/option>/);
  assert.match(page, /id="ftaChannelSatellite"/);
  assert.match(page, /id="ftaChannelTransponder"/);
  assert.match(page, /id="ftaChannelServiceId"/);
});

test('cadastro FTA distingue confirmação do receptor, indicação de fonte e codificação', () => {
  assert.match(page, /FTA confirmado pelo receptor/);
  assert.match(page, /Indicado como FTA na fonte/);
  assert.match(page, /Codificado/);
  assert.match(page, /Não verificado/);
});

test('cadastro FTA usa armazenamento local, pesquisa e valida URL HTTP(S)', () => {
  assert.match(page, /fmdx\.satellite\.fta-channels\.v1/);
  assert.match(page, /ftaChannelSearch/);
  assert.match(page, /https?:/);
  assert.match(page, /localStorage\.setItem/);
  assert.match(page, /title\.textContent=.*item\.name/);
});
