const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const root = path.resolve(__dirname, '../..');

test('0.76.0 documenta perfis upstream IT9175 e IT9308 com evidências separadas', () => {
  const source = fs.readFileSync(path.join(root, 'android/app/src/main/java/br/com/fmdx/android/tv/IsdbtBackendPlan.kt'), 'utf8');
  assert.match(source, /0x048d, 0x275a/);
  assert.match(source, /PUBLIC_HARDWARE_CONFIRMATION/);
  assert.match(source, /0x048d, 0x9308/);
  assert.match(source, /PUBLIC_SUPPORT_NEEDS_TESTING/);
});

test('integração upstream registra limites e cuidados de licença', () => {
  const doc = fs.readFileSync(path.join(root, 'docs/ISDBT-OPENDTV-INTEGRATION.md'), 'utf8');
  assert.match(doc, /Nenhum código-fonte do OpenDTV foi incorporado/);
  assert.match(doc, /GPL-3.0/);
  assert.match(doc, /USB Host\/OTG/);
});
