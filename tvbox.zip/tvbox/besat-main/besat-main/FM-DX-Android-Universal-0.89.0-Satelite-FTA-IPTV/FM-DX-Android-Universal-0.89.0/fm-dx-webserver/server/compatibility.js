'use strict';

// Conservative, format-level guidance. Actual playback depends on codec,
// browser, operating system, CORS, server headers and stream configuration.
function getCompatibilityProfile(format = '', media = '') {
    const key = String(format).toUpperCase();
    const profiles = {
        'MP3': { engine: 'HTML5 Audio', mime: 'audio/mpeg', support: 'ampla', recommendation: 'Use o reprodutor de áudio integrado.' },
        'AAC': { engine: 'HTML5 Audio', mime: 'audio/aac', support: 'variável', recommendation: 'Teste no navegador; o suporte depende do perfil AAC e do sistema.' },
        'OGG': { engine: 'HTML5 Audio', mime: 'audio/ogg', support: 'variável', recommendation: 'Use HTML5 Audio se o navegador reconhecer o codec contido no OGG.' },
        'OPUS': { engine: 'HTML5 Audio', mime: 'audio/ogg; codecs="opus"', support: 'variável', recommendation: 'Prefira navegador moderno com suporte a Opus.' },
        'HLS': { engine: 'HLS nativo ou HLS.js + Media Source Extensions', mime: 'application/vnd.apple.mpegurl', support: 'depende do navegador', recommendation: 'Tente HLS nativo; se indisponível, HLS.js pode funcionar quando Media Source Extensions e codecs forem compatíveis.' },
        'MPEG-DASH': { engine: 'DASH.js + Media Source Extensions', mime: 'application/dash+xml', support: 'depende do navegador', recommendation: 'Use DASH.js em navegador com Media Source Extensions e codecs compatíveis.' },
        'MPEG-TS': { engine: 'Reprodutor MPEG-TS específico ou conversão no servidor', mime: 'video/mp2t', support: 'limitado em HTML5 direto', recommendation: 'O elemento de vídeo normalmente não reproduz MPEG-TS direto; seria necessário um player compatível ou remultiplexação autorizada.' }
    };
    const profile = profiles[key] || (String(media).toLowerCase() === 'radio'
        ? { engine: 'HTML5 Audio', mime: 'audio/*', support: 'não confirmado', recommendation: 'Confirme o MIME e o codec real do stream antes de escolher o player.' }
        : { engine: 'HTML5 Video', mime: 'video/*', support: 'não confirmado', recommendation: 'Confirme o contêiner e o codec real; extensão e MIME não garantem reprodução.' });
    return { format: key || 'DESCONHECIDO', ...profile, caveat: 'Estimativa por formato. Não garante reprodução nem identifica todos os codecs; CORS, autenticação, HTTPS e disponibilidade do servidor também podem impedir o acesso.' };
}

module.exports = { getCompatibilityProfile };
