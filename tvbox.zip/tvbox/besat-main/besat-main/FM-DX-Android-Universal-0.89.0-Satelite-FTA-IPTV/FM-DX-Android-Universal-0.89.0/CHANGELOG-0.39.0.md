# FM-DX Android Universal 0.39.0 — Cross-Device Evidence Comparison

## Novidades
- O Hardware Test Lab agora apresenta uma comparação local das observações já salvas.
- Agrupa registros por família de plataforma inferida somente a partir dos campos públicos de SoC armazenados.
- Resume quantidade de testes, fingerprints distintos e modelos registrados por grupo.
- Mantém histórico local limitado a 100 observações e não envia dados para servidores.
- Atualizados `versionName` para 0.39.0 e `versionCode` para 24.

## Limites
- A comparação é exploratória: mesmo fabricante ou família de SoC não prova que dois aparelhos compartilham tuner, driver, HAL, firmware ou suporte FM.
- O resultado de acesso ao tuner continua como NÃO COMPROVADO até haver teste real e evidência específica do modelo, variante e firmware.
- Não foram adicionadas interfaces privadas, root, bypass de permissões ou tentativa de sintonia não suportada.
