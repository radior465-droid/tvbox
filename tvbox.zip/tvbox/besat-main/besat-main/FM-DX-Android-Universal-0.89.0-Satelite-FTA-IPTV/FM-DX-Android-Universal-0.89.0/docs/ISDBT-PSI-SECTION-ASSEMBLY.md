# Montagem de seções PSI/SI do MPEG-TS

`PsiSectionAssembler` recebe pacotes TS de exatamente 188 bytes e filtra um PID. O fluxo esperado é: backend específico do chipset -> bytes MPEG-TS -> alinhamento de pacotes -> assembler por PID -> parser PAT/PMT já existente.

## Tratamentos implementados
- `adaptation_field_control` e tamanho do campo de adaptação;
- `payload_unit_start_indicator` e `pointer_field`;
- seções que atravessam mais de um pacote;
- várias seções dentro do payload iniciado por PUSI;
- stuffing `0xFF`;
- descarte de fragmentos após salto de continuity counter;
- rejeição de TEI e pacotes embaralhados.

## Limites
O assembler não faz demultiplexação automática de todos os PIDs, não valida CRC-32 MPEG-2, não interpreta descritores ARIB, não decodifica vídeo/áudio e não substitui o driver IT9175. PAT costuma estar no PID 0; PMT usa o PID anunciado pela PAT. Para recepção confiável, a próxima etapa deve incluir CRC, controle de versão/section_number e testes com capturas TS reais licenciadas ou geradas sinteticamente.
