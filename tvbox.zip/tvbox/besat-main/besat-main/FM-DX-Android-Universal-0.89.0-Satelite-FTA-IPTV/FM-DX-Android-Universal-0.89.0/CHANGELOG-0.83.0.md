# FM-DX Android Universal 0.83.0 — Linha do tempo de legendas ISDB-T

- Adicionado modelo limitado de cues de legenda textual com início/fim em milissegundos, texto decodificado por `AribB24Decoder` e idioma opcional.
- Consulta da legenda ativa em um instante, snapshot do histórico e limpeza explícita.
- Proteções para IDs duplicados, tempos inválidos/estourados, blocos vazios ou excessivos e duração máxima de 10 minutos.
- Histórico limitado (padrão 200 cues) para evitar crescimento ilimitado de memória.
- Testes para decodificação, temporização, rejeição de entradas inválidas, deduplicação e limite de histórico.

## Limitações importantes

Esta versão implementa a camada de modelo/apresentação de legendas textuais, recebendo um bloco de bytes ARIB B24 **já extraído**. Ainda não demultiplexa PES de MPEG-TS, não interpreta cabeçalhos/grupos de dados de legenda ARIB completos, não sincroniza relógio PCR/PTS, não renderiza DRCS/bitmaps, posicionamento ou controles de apresentação. Portanto, ainda não recebe nem exibe closed captions reais diretamente do dongle. A integração com um demultiplexador e parser ARIB de legenda é uma etapa futura. Compilação integral do APK e teste físico não realizados.
